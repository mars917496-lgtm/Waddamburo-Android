# Implementation provenance

The equipped nameplate Dan rank is independently integrated from user-supplied
movie callback behavior: ranks 1-25 and normal/gold variants, with 0 hidden.
Name-text placement beside the rank uses measured movie geometry; Entry and the
other nameplates share an inset text box with horizontal compression. Profile fields,
validation and text fitting are project choices. No asset script, artwork or private
implementation is copied. Public tests use synthetic server profiles.

Gameplay scroll scaling is independently implemented from the behavioral rule in
[AioiLight's scroll reference](https://aioilight.space/taiko-no-tatsujin/scroll/)
(consulted 2026-11-04): each note's own BPM and scroll determine its velocity,
with 948 stage pixels per four beats at scroll 1. Aggregate measurements of Green
runtime note trajectories independently corroborate that distance. Target geometry
is asset-derived; its screen-edge distance is not the scroll calibration.
OpenTaiko revision `7b832277b79b8c72258c954db8f09cba9d618ca5` was consulted only
to compare the separation of scroll distance from target position and its different
960-pixel default; no code, constants, or assets were adapted from it. The original
implementation and synthetic regressions introduce no dependency. Raw observations
and private trace details remain outside this repository.

Gameplay Don marker/state selection and fever callbacks were independently checked
using the public runtime with user-supplied movie data. The tempo integrator,
motion-state policy, and camera construction are original project choices; no
private implementation, asset script, or capture is copied. Synthetic fixtures
cover tempo boundaries and native-surface ownership. No dependency was added.
Gameplay composite dimensions, center, and semantic camera framing were measured
from a user-supplied graphics capture. Only geometric behavioral requirements are
recorded publicly; raw draws, shader data, GPU constants, addresses, and screenshots
remain outside the public repository. The gameplay camera is constructed with
standard look-at/perspective operations rather than copying captured matrices.

Audio transport interpolation is an original project timing policy. A monotonic
clock drives playback independently of block-sized queue observations. Audio drift
outside a hardware-buffer uncertainty interval is corrected at at most 1% speed;
unchanged output for the greater of 100 ms or four buffers freezes the clock.
These are project policies, not precise hardware playhead measurements. Synthetic
tests exercise high refresh rates, irregular consumption, and stalled output; no
external implementation was adapted.

Song Select countdown handling is an original host implementation based on the
asset-derived start-duration/poll/stop protocol. Monotonic timing, upward rounding
of displayed seconds, and stopped-timer semantics are explicit product policies.
Course conversion keeps the authored normal/hidden eight-slot domain separate
from the catalog's five-course enum; the supported hidden-Oni slot maps to Ura.
Tests use synthetic calls and an injected clock. No asset script or private
diagnostic output is included.

The stack-based AVM1 frame-jump instruction is independently implemented from
Adobe's *SWF File Format Specification*, version 10, ActionGotoFrame2
([specification mirror](https://www.flashrealtime.com/content/dam/Adobe/en/devnet/swf/pdf/swf_file_format_spec_v10.pdf)).
No reference implementation or private bytecode was copied. Synthetic tests cover
numeric frames, labels, scene bias, playback state, and invalid targets. Nested
function visibility is a project runtime repair with a synthetic regression.
Additional gameplay composition layers were identified from user-supplied asset
relationships; no assets or diagnostic captures are included.

The subsequent gameplay-runtime repairs implement ActionGotoFrame, ActionToInteger,
and FSCommand-form ActionGetURL from the same public SWF specification. FSCommand
is exposed only as an in-process notification; general URLs remain unsupported.
Math.random uses the framework's pseudorandom generator for visual effects, not
judgement. An empty standalone Pop is treated as a no-op as a narrow compatibility
decision based on asset-derived class-guard behavior; other stack requirements
remain checked. No external interpreter source was adapted.

Hit-flight state names and lane placement are asset-derived relationships, also
consistent with the private viewer's observable hit-to-gauge behavior. The public
implementation independently owns a bounded pool of animation players sharing
texture resources; no private implementation, bytecode, or captures were copied.

The gameplay repair in `src/Waddamburo.Game/Gameplay/`, the app gameplay adapter,
and the platform transport/input additions are independently written. Semantic
Lumen integration requirements were derived from the private behavioral oracle;
no private implementation or guessed scoring/gauge formulas were copied. The
clock and judgement separation was informed by osu!lazer commit
`48c4800e3ae4ee752452cdff83bd3787ccf3105f`, specifically
`osu.Game/Screens/Play/GameplayClockContainer.cs` and
`osu.Game.Rulesets.Taiko/Objects/Drawables/DrawableHit.cs` (MIT, ppy Pty Ltd).
The project implements its own source-position estimate, pre-roll scheduling,
input delivery and semantic presentation. See `../development/gameplay-integration.md`
for source links, behavioral requirements, decisions, and limitations.

This repository began as a clean public implementation on 2026-09-19. It does not
inherit the commit history of the private research and proof-of-concept repository.

Unless a file-specific entry says otherwise, Waddamburo code is original project
work by Luca Silva and contributors and is licensed under the root MIT license.

No Zucchini, TaikoRecomp, proof-of-concept viewer, decompiled, or executable-derived
source code is currently included. Private research may supply semantic behavioral
requirements and independently described asset-format facts under the evidence
policy; it is not a source tree for copying implementation code.

Before adding adapted or vendored code, update this document in the same change with:

- the destination file or directory;
- the upstream project, source file, and exact revision;
- the upstream license and retained notice location; and
- whether the change is copied, adapted, generated, or independently implemented
  from documented behavior.

Third-party packages and tools must also be recorded in the root
`THIRD_PARTY_NOTICES.md`.

The dependency recipe in `native/ffmpeg/` is original Waddamburo build
configuration written against FFmpeg's public configure interface. It downloads
the unmodified official FFmpeg 8.1.2 archive by version and SHA-256; no FFmpeg or
private proof-of-concept source is vendored in this repository.

`native/media/src/media.c` is an original decoder wrapper written against FFmpeg's
public libavformat, libavcodec, libavutil, and libswresample APIs. Its NUB behavior
uses the independently described fact that the container carries a complete RIFF/
WAVE stream; no TaikoRecomp, proof-of-concept, executable-derived, or game source
code is copied or translated. Synthetic RIFF data supplies the public regression.

The optional vgmstream integration in `native/media/src/media.c` is original wrapper
code written against vgmstream's public `libvgmstream` API. The dependency recipe in
`native/vgmstream/` is original Waddamburo build configuration against upstream
vgmstream commit `09c9f40caae4747e44b6a993b3d5b654cef4d1f7`. It downloads the
unmodified upstream archive, builds it with G.719 disabled, and vendors no source. Container
selection uses filename extensions and public library behavior. The public decode
regression uses a project-authored, silent synthetic BNSF/IS22 fixture. Private game
audio was used only for local compatibility checks; no sample, hash, path, capture,
or content-derived fixture is stored here. `src/Waddamburo.Platform.Sdl/Media/VgmstreamCli.cs`
runs a user-supplied vgmstream-cli as a separate program for files the bundled decoder
rejects; licensing is recorded in `THIRD_PARTY_NOTICES.md`.

`src/Waddamburo.Providers.OsuLazer/` is original integration code written against
the public Realm 20.1.0 API (dynamic, read-only access; no osu! model assembly). Its
`.osu` reader and taiko conversion rules were checked against osu!lazer's
`LegacyBeatmapDecoder.cs`, `TaikoBeatmapConverter.cs` and `BarLineGenerator.cs`
(ppy/osu commit `48c4800e3ae4ee752452cdff83bd3787ccf3105f`, MIT) and against TaikoRecomp's
own osu! importer; no source is copied or translated.

`src/Waddamburo.Providers.Tja/` is an original managed catalog implementation.
Its format behavior was checked against TaikoRecomp revision
`1dc686003e705194b0187c0cb19e84276504645d`, principally
`docs/custom_songs.md`, `tools/custom_songs.py`, and the MIT-licensed
`tools/vendor/tja2fumen` documentation and parser. No TaikoRecomp or tja2fumen
source is copied, translated, linked, or packaged. The implementation independently
expresses metadata/course normalization, encoding fallback, relative-audio, and
source-identity behavior behind Waddamburo's catalog contracts; synthetic public
tests were authored specifically for this repository.

`src/Waddamburo.Providers.Stock/` is an original managed catalog implementation.
Its fumen layout (header size, measure count offset, measure/branch/note records,
note types, roll padding, big-endian arcade order) follows the MIT-licensed
tja2fumen parser's documentation (`tools/vendor/tja2fumen` in TaikoRecomp revision
`874c5b4751cce16cd63e2f34d678568b980a95e6`). The `musicinfo.xml`, chart/audio path conventions and the `.nsh`
preview cue are asset-derived observations of user-supplied Green data, checked
against the documented host catalog and audio loader descriptions in that TaikoRecomp
revision (`docs/song_select_reversing.md`, `src/taiko_catalog.cpp`,
`src/taiko_audio_decoder.cpp`, `docs/host_song_browser.md`, and the `tuning.bin`
star-rating description in `src/taiko_catalog_tuning.h`), each re-verified against
the user's asset files. The implementation is written independently; no address or
TaikoRecomp source is copied.
Public tests use synthetic XML, fumen and `.nsh` fixtures.

譜面分岐 (branching): the fumen branch-point weights (header 0x1D4) and per-measure thresholds, and the
conversion of TJA `#BRANCHSTART p/r`, `#LEVELHOLD` and point-weight selection to them, follow the
MIT-licensed tja2fumen documentation and converter (`tools/tja2fumen` in the Waddamburo lab, as vendored
2026-09-27); the check one measure before the branch is the TJA format's own rule. Which charts branch was
measured on the user's Green fumens (thresholds plus differing routes) and Nijiiro `musicinfo` flags. The
lane's route display uses `lane_hit.lm`'s own `SetBranchAvailable`/`SetBranch` callbacks and
`lane_syousetsu.lm`'s `bunki` frame, and song select's 分岐 mark its `Callback_SetPapamamaSeparateBits`,
all read from the user's Green movies. No tja2fumen source is copied or translated. The bubble beside Don
at a route change is `fukidashi_level_1p.lm`'s own `level_up`/`level_down` labels; when it plays was observed
in a play session.

`src/Waddamburo.Catalog/PlayableChart.cs` and the playable-chart conversion in
`src/Waddamburo.Providers.Tja/` are original Waddamburo implementations. Their
separation of absolute-time hit objects from timing, scroll, and effect control
points was architecturally informed by the MIT-licensed osu!lazer source at commit
`48c4800e3ae4ee752452cdff83bd3787ccf3105f`, principally
`osu.Game/Beatmaps/ControlPoints/ControlPointInfo.cs`, `TimingControlPoint.cs`,
`osu.Game/Rulesets/Scoring/HitWindows.cs`, and the Taiko ruleset's
`Objects/Drawables/DrawableHit.cs` and `Scoring/TaikoHitWindows.cs`. No osu! source
is copied verbatim, linked, or packaged; the TJA timeline conversion and public
synthetic regressions were independently written for Waddamburo. The retained
upstream attribution is recorded in `THIRD_PARTY_NOTICES.md`.

The Song Select host, native-fill surface contract, package bootstrap, and dynamic
MovieClip behavior are original public implementations. Behavioral expectations
were checked against the private experimental viewer and user-supplied Green assets
under the evidence policy; no viewer source, game asset, font, screenshot, trace,
or content inventory is copied or packaged.

`src/Waddamburo.Formats/Audio/NuSoundBankCatalog.cs` and the authored-audio host
adapters are original implementations from asset-derived table facts and observed
movie-to-host call behavior. The public regression constructs a synthetic big-endian
bank-name table. Local compatibility checks established only the numeric-bank/name
relationship, zero-based cue relationship, and voice lifecycle ordering; no game
table, audio, identifier inventory, trace, decompilation, or proof-of-concept source
is copied or packaged. Multi-stream selection is implemented independently against
vgmstream's public API described above.

The independently written FreeType implementation in `native/text/src/text.c`
adapts song-title typography constants and Unicode-layout sets from
TaikoRecomp `src/taiko_title_render.c` at
`1dc686003e705194b0187c0cb19e84276504645d` and TaikoZucchini
`core/title_render.c` at `f3273008d24682f42e089bcf407508390abbc7d7`.
Both sources are MIT-licensed, copyright 2026 Luca Silva. The adaptation retains
the compact/expanded dimensions, font/leading/outline proportions, punctuation
rotation, small-glyph spacing, and subtitle-column behavior, but implements a new
bounded C ABI, UTF-8 decoder, mask compositor, DPI scaling, and managed cache for
Waddamburo. It accepts only an explicit user-owned font path; no font or source
asset is copied or packaged. The retained MIT attribution is recorded in
`THIRD_PARTY_NOTICES.md` and the repository `LICENSE` carries the same terms and
copyright owner.

`src/Waddamburo.Platform.Sdl/SdlApplication.cs` is original integration code written
against SDL's public GPU API and the generated `ppy.SDL3-CS` 2026.722.0 bindings.
No SDL or binding source is copied into the repository; the NuGet package supplies
the dynamically loaded platform-native SDL library.

Rendering goes through bgfx (bgfx.cmake v1.161.9510-579, BSD-2-Clause), built from
its pinned release archive by `native/bgfx` and loaded dynamically. Its generated C#
bindings are vendored unchanged as `Rendering/Bgfx/bgfx.generated.cs` apart from one
added line marking the file generated. The compositor, Don renderer, and their
`.sc` shader sources under `src/Waddamburo.Platform.Sdl/Shaders/Bgfx/` are original
Waddamburo code ported from the earlier SDL_GPU implementation; bgfx's documented
API and shader conventions were the only references. The checked-in binaries in
`Shaders/Compiled/` are generated by the unmodified bgfx `shaderc` via
`eng/build-shaders.*`; shaderc is not vendored or shipped at runtime.


The expanded TJA gameplay reader and long-note session/presentation are original
project implementations. Format facts were checked against the public
[taiko-web TJA documentation](https://github.com/269Seahorse/Better-taiko-web/blob/master/TJA-format.mediawiki)
(master, accessed 2026-09-22) and the
[TJAPlayer3 format reference](https://iepiweidieng.github.io/TJAPlayer3/tja/)
(revision dated 2026-09-13). No upstream implementation or private PoC code was
copied or adapted, and no dependency was added. Fixed branch selection, permissive
long-note closure, missing-quota defaults, and chart-load
recovery are Waddamburo product policies, not original-game behavior claims.
All new regression fixtures are synthetic.


The authored long-note presentation adapters are independently written from
user-supplied movie interface facts (callbacks, labels, and native-fill semantics).
No movie scripts, assets, captures, private PoC code, or identifier inventory are
copied into the repository. The AVM1 NewMethod and ColorTransform support was
implemented against the public
[Adobe SWF specification](https://www.flashrealtime.com/content/dam/Adobe/en/devnet/swf/pdf/swf_file_format_spec_v10.pdf)
and [ActionScript 2 ColorTransform reference](https://open-flash.github.io/mirrors/as2-language-reference/flash/geom/ColorTransform.html)
(accessed 2026-09-22), with original synthetic bytecode fixtures. No code was
adapted and no dependency was introduced.

Timeline clip-depth interpretation is independently derived from user-supplied
placement data and observed mask/artwork relationships. Stencil command scoping,
the binary alpha threshold, and backend implementation are original project
choices. The backend uses SDL's public
[depth/stencil state](https://wiki.libsdl.org/SDL3/SDL_GPUDepthStencilState) and
[render-target API](https://wiki.libsdl.org/SDL3/SDL_GPUDepthStencilTargetInfo)
(accessed 2026-09-22). Tests use synthetic shapes, textures, and placements. No
private implementation, asset, or raw capture is copied. The new mask shaders use
the project's shader toolchain (now bgfx shaderc); no dependency was added.

`Waddamburo.Providers.Stock/Data/stock-metadata.tsv` (stock musicid → subtitle, English
title, English subtitle) is generated data: Green's `musicinfo.xml` has only the Japanese
title, so each stock title was matched against the community ESE/TJADB TJA library's
`TITLEJA`/`TITLE` and the match's `SUBTITLEJA`/`SUBTITLE`/`TITLE` values kept (song credits
and title translations, no chart or game data). The generator stays in the private lab
repository (`tools/stock_subtitles/build.py`, 2026-09-28).

Texture upscaling uses the Real-ESRGAN `realesr-animevideov3` model (BSD-3-Clause, copyright
2021 Xintao Wang): the ncnn `.param`/`.bin` files from the v0.2.5.0 release archive
`realesrgan-ncnn-vulkan-20220424-ubuntu.zip` are vendored unchanged in
`src/Waddamburo.App/Upscale/` with the license text beside them (hashes in
THIRD_PARTY_NOTICES.md). The CPU inference in `Presentation/CompactUpscaler.cs` is written
independently from the network layout in the `.param` file and the ncnn weight-file layout
(fp16-tagged convolution weights, fp32 biases and PReLU slopes, 2026-09-29); no Real-ESRGAN
or ncnn source is copied. Upscaled textures are derived locally from the user's own files and
cached on their machine only.

The upscaled-texture cache stores BC7 blocks encoded by bc7enc (bc7enc_rdo, MIT or public
domain, copyright Richard Geldreich, Jr.), vendored unchanged in `native/texture/third_party/bc7enc/`
at commit `b9438627eef73a1157e84201b6fa6eb2ffd6d9f0` (hashes in THIRD_PARTY_NOTICES.md). The
`waddamburo_texture` C ABI around it and the C# bindings are original project code.

The effects editor uses ImGui.NET 1.91.6.1 (upstream revision
`8e26803be78b344fd68834817905405b3cdffb94`, MIT) and its bundled Dear ImGui 1.91.6 /
cimgui native runtimes from NuGet. The native library includes Dear ImGui's embedded ProggyClean (MIT); the editor uses
the project's existing Kosugi Maru resource (Apache-2.0, exact source and hash in THIRD_PARTY_NOTICES.md),
rasterized into the ImGui atlas at the window's initial pixel density. Their notices ship from `eng/packaging/licenses/`; the exact
managed dependency graph is recorded in the package lock files. The SDL event
adapter, bgfx indexed-triangle renderer, and editor session are original project
code, implemented against the published Dear ImGui backend contract
(<https://github.com/ocornut/imgui/blob/v1.91.6/docs/BACKENDS.md>) and ImGui.NET API.
No upstream backend source or private proof-of-concept code is adapted.

The effects editor's neutral theme, inline timeline curves and scene manipulation controls are original
project code. BUI was evaluated from its public README (<https://github.com/ppmpreetham/BUI>, accessed
2026-11-07) as a UI reference; no BUI or Blender code, assets, theme tables, or dependencies are included.

The editor's asynchronous open/save picker is original Platform.Sdl code against SDL 3's public
`SDL_ShowOpenFileDialog` / `SDL_ShowSaveFileDialog` APIs (available since SDL 3.2.0;
<https://wiki.libsdl.org/SDL3/SDL_ShowOpenFileDialog>,
<https://wiki.libsdl.org/SDL3/SDL_ShowSaveFileDialog>, accessed 2026-11-07).
Filter buffers live until SDL's callback completes. No upstream dialog implementation is copied;
the existing SDL binding/native dependency and notices are unchanged.
