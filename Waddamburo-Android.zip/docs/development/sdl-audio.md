# SDL audio output

`Waddamburo.Platform.Sdl.Media.SdlAudioDevice` owns the current playback sink.
It initializes the SDL audio subsystem, opens the system's default logical playback
device, and presents one fixed application-side stream: interleaved 32-bit float,
48 kHz, stereo. SDL may choose a different physical format and converts between the
two; the selected driver, hardware rate/channel count, and hardware buffer size are
exposed for diagnostics.

The device starts paused. Producers call `Queue` from their worker thread, bound the
amount reported by `QueuedFrames`, and call `Flush` when no more source data will be
submitted. The owner controls `Resume`, `Pause`, and `Clear`. Native calls and
destruction share one lock so a producer cannot write through an SDL stream while it
is being destroyed. `SubmittedFrames` is the first piece of playback accounting; it
does not yet claim to be a played-sample clock because SDL and the physical device
may hold additional buffered frames.

`StreamingMusicPlayer` handles long-form diagnostic playback. It decodes blocks into
a reusable managed buffer and keeps at most roughly half a second on SDL's
application-side queue. It borrows the device rather than opening or closing one
itself.

`AudioEngine` is the first software-mixed path. Its background producer renders
128-frame blocks and targets 512 queued application frames. The device
requests a 256-frame hardware period unless the user sets
`SDL_AUDIO_DEVICE_SAMPLE_FRAMES`; the actual period is backend-dependent.
`AudioMixer`
provides BGM, preview, menu-sound, voice, and drum-hit buses, master/per-bus volume,
bus mute, concurrent voices, looping, immediate stop, and sample-counted fade-out.
Mixing is additive float with final saturation to `[-1, 1]`.

`AudioClip` predecodes short one-shots into the device format, defaults to a
30-second safety limit, and never permits a limit above two minutes. This is
appropriate for jingles and effects. Clips retain an optional half-open authored
loop region. The mixer plays the intro once, wraps from the authored end back to
the authored start, and does not replay codec tail padding. Stock ATRAC NUBs expose
that range through their enclosing RIFF `smpl` chunk even when the elementary
stream decoder has no loop metadata. `BufferedAudioSource` incrementally decodes a
provider-owned `Stream` into a bounded half-second PCM ring. Its mixer-facing read
never waits for the decoder, and stopping the voice cancels decoding and releases
both the native decoder and input stream. `NativeAudioDecoder` keeps managed stream
callbacks rooted for the native decoder lifetime and supports seek and cancellation
through the same C ABI as file decoding. Loading happens before `Play`, never on the
mixer producer.

The `--play-audio=` diagnostic exercises streaming music. `--play-jingle=` decodes a
short user-owned file; in the Entry-to-Song-Select composition it plays on the BGM
bus. When a sound root is present and no override is supplied, that composition
resolves and loops the user-owned `bgm/nub/JINGLE_ENTRY.nub` during Player Entry.
On activation it stops that voice and loops Song Select's distinct
`bgm/nub/JINGLE_GENRE.nub`. Both paths print SDL's selected hardware format.

The interactive Entry-to-Song-Select flow opens one shared audio device (bounded
screenshot runs stay silent unless audio is explicitly requested). Song Select
resolves opaque catalog audio keys through their owning provider, waits for a 250 ms
stable hover, seeks to the chart's preview time, and plays the bounded stream
on the preview bus. Superseding, stopping, selecting, or disposing the scene cancels
pending catalog I/O and decoding; the active browser-music voice fades for 100 ms.
Generation checks prevent a completed asynchronous open from attaching to a
superseded scene. The authored `NotifyStopBGM(category, song)` call selects one
logical browser-music slot: valid song coordinates fade the previous voice out,
leave the debounce/decode interval silent, then fade the preview in over 300 ms.
The movie sends `song = -1` for Return and other non-song boards. Leaving a preview
fades it immediately and restarts `JINGLE_GENRE`. Moving among non-song boards
leaves an already playing jingle untouched, including a Return confirmation that
closes a category. The jingle and previews therefore never play concurrently.

Entry and Song Select now forward their authored `RequestSE`, `RequestSystemSE`,
`RequestPlayerSE`, `NotifyPlayLoopVO`, and `StopVoice` calls across typed host
contracts. In the Entry-to-Song-Select diagnostic, `--sound-root=` points at a
user-owned nuSound2 tree containing `config/nuSound2BankStr.bin` and `se/*.nub`.
The bounded table parser maps authored numeric bank IDs to sanitized bank names;
`RequestSE(bank, cue)` selects the one-based NUB substream `cue + 1`. `VO_` banks
play exclusively on the voice bus, while other banks play on the menu-sound bus.
A `vag` stream header carries a start delay in milliseconds at `+0x4C` (e.g. the
end-of-song full-combo voice waits 1200 ms for its banner text); the cue plays after
that much silence.
An authored loop notification replays the latest voice once only when it is no
longer active; it does not create an unbounded PCM loop. Category announcements
also play once and continue when their folder opens. `StopVoice` stops any active
voice. Entry keeps an accepted scene
transition pending until the ordinary or replayed voice completes.
Song Select's observed player-effect protocol carries a drum-tone ID and a semantic
hit kind. Browser feedback uses the common `SE_COM` bank: cue 0 for Don (centre)
and cue 3 for Ka (rim). The close-folder hit kind substitutes `SE_COM` cue 6 for
Don. This remains driven by authored
`RequestPlayerSE` calls, not by platform-specific key bindings, and plays on the
dedicated drum-hit bus.
Unknown system and player-effect shapes are traced.
Player Entry's observed `RequestSystemSE(0, hit)` shape routes hit `0` to the
common-bank Don cue and hit `1` to Ka. Song Select uses its separate observed
`RequestPlayerSE(player, hit)` shape for the same samples.
Revival forwards its observed `SE_REQUEST(group, cue)` and
`VOICE_REQUEST(group, cue)` calls through a typed scene host contract. The verified
request pairs select `SE_REVIVAL`, `VO_REVIVAL`, or `SE_COM` on the existing buses;
the drum-roll hit uses the drum-hit bus. Its `SOUND_STOP_ALL` call stops all mixer
buses and clears held voice ownership. `BGM_START` loops the user-owned
`bgm/nub/JINGLE_RENDA.nub` on the BGM bus when the roll begins. The music is
preloaded in the observed game sessions before Revival, and this file was checked
through the public decoder.
Gameplay input plays the default `SE_GAME_NEIRO_000_C` Don/Ka samples on the
drum-hit bus. They are decoded during the covered scene transition. Judgement
and long-note events trigger the verified combo, balloon and kusudama cues, while
the end banner and finished-song handoff trigger their observed effects and
voices. Result movie sound requests also route the traced effects and Don-chan
voices for clear, fail and full combo. Results loop `JINGLE_SEISEKI` on the BGM
bus until leaving the scene. The end-of-credit screen starts `JINGLE_CARDRECOM`,
switches to `JINGLE_GOVER` on its movie request, and plays the traced
`SE_GAMEOVER` and `VO_HOWTOPLAY` cues. The cue table is in
[`green-sound-inventory.md`](green-sound-inventory.md).
When a root category settles, authored `NotifyGenreFolder(category, -1, false)`
is resolved through the pinned catalog's semantic category name rather than its
display index. The audio adapter maps the verified `VO_SELECT` cues as Namco
Original (0), J-POP (1), Game Music (2), Classical (3), Variety (4), Anime (5),
Kids (6), Vocaloid (7) and the tutorial folder (12). Medley remains unresolved. The
category announcement plays once on the voice bus and can finish after its
folder opens. The
verified mappings and intentionally unresolved ranges are maintained in
[`green-sound-inventory.md`](green-sound-inventory.md).

`SdlAudioDeviceTests` opens the available playback backend, queues silent float
frames while paused, verifies queue accounting and clearing, and exercises resume,
pause, argument validation, and idempotent teardown. `AudioMixerTests` use synthetic
PCM to lock bus summation, volume, saturation, mute timing, looping, fade-out, clip
ownership, streaming-source mixing/disposal, full teardown, and format rejection.
The managed callback bridge is also checked locally with a synthetic in-memory WAV,
including frame seek; no game audio is used by that check.

`--preview=PATH` opens a file browser for a user-owned USRDIR, DDP, NUB, or audio
file. The older `--probe-sound-bank=PATH` command opens the same browser. Select a
bank with Up/Down and Enter (or click it); D/K changes cue. Type a
zero-based cue number and press Enter to select it directly. Space pauses/resumes;
R replays. Audio streams on demand rather than preloading all bank cues. Details
appear in the window and console. See [diagnostics](diagnostics.md) for movie selection
and timeline controls. This supports listening-based identification without adding
extracted media to the repository.

Still intentionally absent are complete system/player-effect mappings, source
pause/resume, mixed gameplay BGM, a played-sample clock, underrun/device-change
recovery, and persistent latency offsets. Those remaining pieces belong to PLT-024
through PLT-028.
