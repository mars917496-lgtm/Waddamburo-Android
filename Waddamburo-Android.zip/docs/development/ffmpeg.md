# Pinned FFmpeg build

Waddamburo builds FFmpeg 8.1.2 from the official source archive. CMake verifies
the archive against SHA-256
`464beb5e7bf0c311e68b45ae2f04e9cc2af88851abb4082231742a74d97b524c`
before extraction. Downloads, extracted sources, objects, and installed libraries
remain below ignored `out/` directories.

The configuration builds dynamic `avutil`, `avcodec`, `avformat`, `swresample`,
and `swscale` libraries. It disables automatic dependency discovery, static
libraries, programs, devices, filters, networking, GPL components,
nonfree components, and version-3-only components. The one external codec library
is libopus 1.5.2 (BSD-3-Clause, SHA-256
`65c1d2f78b9f2fb20082c38cbe47c951ad5839345876e46941612ee87f9a7ce1`, matching xiph's
SHA256SUMS), built static with PIC into the same prefix and linked into `avcodec`: it
re-encodes vgmstream-cli's WAV output as Opus for the decoded-audio cache
(`waddamburo_media_transcode_opus`, ABI 1.4). FFmpeg's own Opus encoder is not used: its
psychoacoustic queue overflows and drops audio on songs that start with silence.

The allowlist supports the product's declared inputs:

| Kind | Enabled components |
| --- | --- |
| Decoders | ATRAC3plus; H.264 (attract movies); MP3; Vorbis; Opus; FLAC; unsigned 8-bit, signed 16/24/32-bit, and float 32-bit little-endian PCM |
| Demuxers | WAV, MP3, Ogg, FLAC; MPEG program stream (PAMF movies) and raw H.264 (its stream probe) |
| Parsers | MPEG audio, Vorbis, Opus, FLAC, H.264 |
| Scaling | `swscale` converts decoded YUV movie frames to RGBA |
| Protocols | Local files only; managed-memory inputs use Waddamburo's AVIO callbacks |
| Encoders | libopus (the decoded-audio cache) |
| Muxers | Ogg (the decoded-audio cache) |

Build the Linux dependency from the repository root with:

```sh
cd native
cmake --preset linux-ffmpeg
cmake --build --preset linux-ffmpeg
cmake --preset linux-audio-pinned
cmake --build --preset linux-audio-pinned
ctest --preset linux-audio-pinned
```

The installed prefix is
`../out/build/native/linux-x64/linux-ffmpeg/ffmpeg/prefix` relative to `native`.
The build preset finishes by auditing the generated FFmpeg configuration against
the exact component allowlist and checking the shared libraries and compliance
files.

`linux-audio-pinned` links `waddamburo_media` against that prefix and runs a
synthetic decode test. Developers with compatible system FFmpeg headers may use
`linux-audio` for faster iteration; release and compatibility conclusions must use
the pinned preset.

For a local Linux playback smoke test, build the managed app and put the media
library and its four pinned FFmpeg shared libraries on the loader path:

```sh
LD_LIBRARY_PATH=out/build/native/linux-x64/linux-audio-pinned/stage/Release/lib:\
out/build/native/linux-x64/linux-ffmpeg/ffmpeg/prefix/lib \
  dotnet run --project src/Waddamburo.App -- --play-audio=/path/to/song.ogg
```

The same entry point accepts MP3, Ogg/Vorbis, Opus, FLAC, WAV, and Green NUB files.
It is diagnostic scaffolding for the streaming decoder, not the final BGM/preview/
sound-effect mixer. SDL device ownership and queue semantics are documented in
[`sdl-audio.md`](sdl-audio.md).

## vgmstream backend and Nijiiro audio

The game's nuSound2 `.nub` banks (sound effects and voices are cues inside them) and
NUS3BANK/BNSF files use a vgmstream backend. `native/vgmstream/` downloads pinned
vgmstream source and builds it as a static library with G.719 disabled: the G.719
reference code has no identified open-source redistribution grant, so Waddamburo never
builds, downloads, or ships it. To build the Linux decoder with both backends:

```sh
cd native
cmake --preset linux-ffmpeg
cmake --build --preset linux-ffmpeg
cmake --preset linux-audio-complete
cmake --build --preset linux-audio-complete
ctest --preset linux-audio-complete
```

Release packages (`eng/package.sh`, see [native-builds.md](native-builds.md)) always
include this backend. Nijiiro BNSF/IS22 audio is G.719, so the bundled decoder rejects
it; the managed decoder then runs a user-supplied `vgmstream-cli` (an official
vgmstream release, placed next to the Waddamburo executable, in a `vgmstream` folder
beside it, or on `PATH`), decodes the file once to a WAV in the user cache
(`$XDG_CACHE_HOME` or `~/.cache`, `%LOCALAPPDATA%` on Windows, under
`Waddamburo/vgmstream`), and plays that. In the background the WAV is re-encoded as
160 kbit/s Opus in Ogg (about a tenth of the size) and removed; later plays use the
Opus file. Loop points are dropped with the WAV (these banks are songs, played once).
Without `vgmstream-cli` those files report the backend error and a one-time hint, and
the settings' Nijiiro row says the music needs it.

With `linux-audio-complete`, file inputs ending in `.nub`, `.nus3bank`,
`.nus3audio`, `.bnsf`, `.spsis14`, `.spsis22`, or `.idsp` are routed to
vgmstream. A single-stream `.nub` that vgmstream does not recognize falls back to
the bounded embedded-RIFF scanner and FFmpeg; this covers ATRAC-family NUBs without
weakening selected-cue routing. Decoder ABI 1.1 accepts a one-based source-stream index (zero retains
the default/first stream), allowing individual cues in multi-stream banks to be
decoded without extracting them. Callback-backed inputs continue through FFmpeg
and therefore do not support these formats yet. The ABI regression constructs a
silent synthetic BNSF/IS22 file; no commercial audio is stored in the repository.

The Windows preset expects a Visual Studio x64 developer environment plus Bash,
Make, and `cmp` (from `diffutils`) from MSYS2. It selects FFmpeg's MSVC toolchain and produces DLLs rather
than MinGW static archives:

```sh
cd native
cmake --preset windows-ffmpeg
cmake --build --preset windows-ffmpeg
```

Windows remains an unvalidated recipe until its CI job lands. Do not publish its
artifacts based only on successful Linux validation.

The exact source URL, hash, component allowlist, link mode, and license-copy step
live in `native/ffmpeg/CMakeLists.txt`. Any version or option change requires a
fresh upstream-license review, lockstep notice update, and review of FFmpeg's
generated `config.h` and `ffbuild/config.mak`.

Upstream references:

- <https://ffmpeg.org/download.html>
- <https://ffmpeg.org/legal.html>
- <https://ffmpeg.org/doxygen/8.1/md_LICENSE.html>
