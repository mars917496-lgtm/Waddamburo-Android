using Waddamburo.Game.Don;
using Waddamburo.Game.Gameplay;
using Waddamburo.Game.Scores;
using Waddamburo.Lumen.Runtime;

namespace Waddamburo.Game.Lumen;

public enum ResultSoundRequestKind { Effect, Voice }

/// <summary>A results sound request; Cleared / FullCombo are the requesting player's (any player's for
/// shared group 0). TwoPlayers: the movie runs its two-player presentation.</summary>
public readonly record struct ResultSoundRequest(
    ResultSoundRequestKind Kind, int Group, int Cue, bool Cleared, bool FullCombo, bool TwoPlayers = false);

public interface IResultSoundController
{
    void RequestSound(ResultSoundRequest request);
}

/// <summary>
/// The results screen (enso_result/result.lm) as the game drives it (traced, research/traces): each
/// player's numbers and name board at load; the movie then animates on its own, asking the host for
/// Don-chan's motions (ExternalInterface.call("DonMot", player, in, loop)) and sounds
/// (LumenMethod.SE_REQUEST / VOICE_REQUEST, group 1/2 = the left/right player, 0 = both).
/// </summary>
/// <param name="results">One play (the player on <paramref name="side"/>), or two (left, right).</param>
/// <param name="stage">The song play count sent to the results movie.</param>
/// <param name="endMessage">The end message selected for the results movie.</param>
/// <param name="don">Optional Don presentation for movie motion requests.</param>
/// <param name="sounds">Optional controller for movie sound requests.</param>
/// <param name="side">The side of a solo player: 0 left, 1 right.</param>
public sealed class ResultHostBinding(
    Func<IReadOnlyList<TaikoPlayResult>> results,
    int stage,
    int endMessage,
    IDonPresentationController? don = null,
    IResultSoundController? sounds = null,
    int side = 0) : ILumenHostBinding
{
    /// <summary>
    /// The player's best on the chart before this play, by play index; a first play sends its own
    /// score (traced). null: a guest, nothing saved. result.lm shows its "自己ベスト" puff (the old
    /// best, then the new score) only for 0 &lt;= best &lt; score, so a first play shows none.
    /// </summary>
    public Func<int, long?>? Best { get; init; }

    /// <summary>The play's place on the chart's online top three, by play index (null: none, nothing sent).</summary>
    public Func<int, RankingPlacement?>? Placement { get; init; }

    /// <summary>
    /// AI battle's normal results (ghost/result's result_normal, traced): no run mode, SetFullComboType and
    /// SetSupportFlag after the numbers, its counting sounds (SE_REQUEST(1, n)) from SE_AIBTL_RSLT (cue n + 7), and
    /// NotifyCloseNormalResult when it closes.
    /// </summary>
    public bool AiBattle { get; init; }

    /// <summary>AI battle: a named bank's cue (the counting sounds).</summary>
    public Action<string, int>? PlayCue { get; init; }

    /// <summary>AI battle: the normal results closed (the section results come next).</summary>
    public Action? NormalResultClosed { get; init; }

    private LumenHostContext? _context;

    public void Install(LumenHostContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        _context = context;
        context.RegisterExternalInterfaceCall(call =>
        {
            if (call.Arguments.Length > 0 && call.Arguments[0].Kind == LumenHostValueKind.Text
                && call.Arguments[0].AsString() == "DonMot" && don is not null)
                DonLumenBinding.ApplyMotion(context, don, call.Arguments[1..], ResultMotionName);
            return LumenHostValue.Undefined;
        });
        context.RegisterObject("LumenMethod", method =>
        {
            method.RegisterMethod("SE_REQUEST", call =>
            {
                if (AiBattle && tryInteger(call.Arguments, 0, out var bank) && bank == 1 && tryInteger(call.Arguments, 1, out var cue))
                {
                    PlayCue?.Invoke("SE_AIBTL_RSLT", cue + 7);
                    return LumenHostValue.Undefined;
                }
                return requestSound(ResultSoundRequestKind.Effect, call);
            });
            method.RegisterMethod("NotifyCloseNormalResult", _ =>
            {
                NormalResultClosed?.Invoke();
                return LumenHostValue.Undefined;
            });
            method.RegisterMethod("VOICE_REQUEST", call => requestSound(ResultSoundRequestKind.Voice, call));
        });
    }

    private LumenHostValue requestSound(ResultSoundRequestKind kind, LumenHostCall call)
    {
        if (sounds is not null
            && tryInteger(call.Arguments, 0, out var group)
            && tryInteger(call.Arguments, 1, out var cue))
        {
            var plays = results();
            var own = group is 1 or 2 && plays.Count == 2 ? [plays[group - 1]] : plays;
            sounds.RequestSound(new ResultSoundRequest(kind, group, cue, own.Any(play => play.Cleared),
                own.Any(play => play.FullCombo), plays.Count == 2));
        }
        return LumenHostValue.Undefined;
    }

    private static bool tryInteger(
        System.Collections.Immutable.ImmutableArray<LumenHostValue> arguments, int index, out int result)
    {
        result = 0;
        if ((uint)index >= (uint)arguments.Length || arguments[index].Kind != LumenHostValueKind.Number)
            return false;
        var value = arguments[index].AsNumber();
        if (!double.IsFinite(value) || value != Math.Truncate(value)
            || value < int.MinValue || value > int.MaxValue)
            return false;
        result = (int)value;
        return true;
    }

    /// <summary>
    /// The calls the game makes when the results load (guest players). <c>side</c> 1 = the right
    /// drum's player alone (traced session8-p2-solo): its status flag and player index, and an end
    /// message of 0 whatever follows. Two players (session9-2p): both flags, each player's numbers,
    /// then each name board (board = player).
    /// </summary>
    public void Attach(LumenPlayer player)
    {
        ArgumentNullException.ThrowIfNull(player);
        // Both players stand left of their panel, facing it: the second's Don-chan takes the unmirrored camera too.
        if (don is not null)
            DonLumenBinding.Attach(player, don, DonPresentationLayout.OpposedPlayers);
        var plays = results();
        var two = plays.Count == 2;
        if (!AiBattle)
            call(player, "SetRunMode", number(0));
        call(player, "SetSongPlayCount", number(stage));
        call(player, "SetPlayerStatus", LumenHostValue.FromBoolean(two || side == 0), LumenHostValue.FromBoolean(two || side == 1));
        call(player, "SetEndMessage", number(endMessage));
        for (var index = 0; index < plays.Count; index++)
        {
            sendPlay(player, plays[index], two ? index : side, Best?.Invoke(index));
            if (AiBattle)
            {
                call(player, "SetFullComboType", number(0));
                call(player, "SetSupportFlag", LumenHostValue.FromBoolean(false));
            }
            if (Placement?.Invoke(index) is { } placement)
                sendRanking(player, two ? index : side, placement);
        }
        for (var index = 0; index < plays.Count; index++)
            sendName(player, two ? index : side, boardIndex: two ? index : 0);
    }

    private static void sendPlay(LumenPlayer player, TaikoPlayResult play, int side, long? best)
    {
        var p = number(side);
        var no = LumenHostValue.FromBoolean(false);
        call(player, "SetCourse", p, number(play.CourseIndex));
        call(player, "SetScore", p, number(play.Score));
        call(player, "SetBestScore", p, number(best ?? -10)); // -10: a guest
        call(player, "SetRyo", p, number(play.Great));
        call(player, "SetKa", p, number(play.Good));
        call(player, "SetFuka", p, number(play.Miss));
        call(player, "SetCombo", p, number(play.MaxCombo));
        call(player, "SetRenda", p, number(play.Rolls + play.BalloonHits)); // balloons count too (reported on Discord)
        call(player, "SetGauge", p, number(play.GaugeSegments));
        call(player, "SetResultLevel", p, number(play.ResultLevel));
        call(player, "SetFullCombo", p, number(play.FullCombo ? 1 : 0));
        // Traced (no options): SetOptionSpeed 1, the rest false / 0.
        var options = play.Options;
        call(player, "SetOptionSpeed", p, number(options.SpeedIcon)); // Green's art by range
        call(player, "SetOptionDoron", p, LumenHostValue.FromBoolean(options.Doron));
        call(player, "SetOptionAbekobe", p, LumenHostValue.FromBoolean(options.Abekobe));
        call(player, "SetOptionRandomLevel", p, number((int)options.Random));
        call(player, "SetOptionShinuchi", p, LumenHostValue.FromBoolean(options.Shinuchi));
    }

    // Traced (card player): after the numbers, each top-three slot (empty ones as 0, "") then the
    // play's slot; the movie shows its rank-in panel for slots 0-2. A guest's results send neither.
    private static void sendRanking(LumenPlayer player, int side, RankingPlacement placement)
    {
        var p = number(side);
        for (var rank = 0; rank < RankingBoard.Size; rank++)
        {
            var line = rank < placement.Top.Count ? placement.Top[rank] : null;
            call(player, "SetRanking", p, number(rank), number(line?.Score ?? 0), LumenHostValue.FromString(line?.Name ?? ""));
        }
        call(player, "SetRankIn", p, number(placement.RankIn));
    }

    // The name board calls end with the board index (0 for one player), not the player.
    private static void sendName(LumenPlayer player, int side, int boardIndex)
    {
        var playerName = TaikoGuest.Name(side);
        var board = number(boardIndex);
        var p = number(side);
        call(player, "SetPlayerForPlayerName", p, board);
        call(player, "SetTitleForPlayerName", LumenHostValue.FromString(TaikoGuest.Title(side)), board);
        call(player, "SetTitlePanelForPlayerName", number(TaikoGuest.TitlePlate(side)), board);
        var rank = TaikoGuest.DanRank(side);
        call(player, "SetDaniForPlayerName", number(rank), LumenHostValue.FromBoolean(TaikoGuest.DanGold(side)), board);
        // Kana-only glyphs: the name is host text over this board's names clip (see NameText).
        call(player, "SetNameSizeForPlayerName", number(0), board);
        call(player, "ApplyForPlayerName");
        NameText.Show(player, $"board{boardIndex + 1}p/name_board/names", playerName, ranked: rank > 0);
    }

    private static LumenHostValue number(double value) => LumenHostValue.FromNumber(value);

    // result.lm sends numeric DonMot IDs without defining DON_* globals. These pairs are the
    // entrance/idle and outcome motions observed across normal one- and two-player result traces.
    internal static string? ResultMotionName(int id) => id switch
    {
        30 => "don_result_in",
        31 => "don_result_loop",
        32 => "don_result_clear",
        33 => "don_result_clear_loop",
        34 => "don_result_clear_koshibai",
        35 => "don_result_failure",
        36 => "don_result_failure_loop",
        37 => "don_result_failure_koshibai",
        38 => "don_result_full",
        39 => "don_result_full_loop",
        40 => "don_result_full_koshibai",
        41 => "don_result_percious",
        42 => "don_result_percious_loop",
        43 => "don_result_percious_koshibai",
        _ => null,
    };

    // AI battle's result_normal has no SetEndMessage (the game's call does nothing there, traced) nor SetRunMode.
    private static readonly string[] Optional = ["SetEndMessage", "SetRunMode"];

    private static void call(LumenPlayer player, string name, params LumenHostValue[] arguments)
    {
        if (!player.TryInvokeCallback(name, arguments) && !Optional.Contains(name))
            throw new InvalidDataException($"Result movie is missing callback '{name}'.");
    }
}
