using Waddamburo.Lumen.Rendering;
using Waddamburo.Lumen.Runtime;

namespace Waddamburo.Game.Don;

public readonly record struct DonMotionRequest(int PlayerIndex, string? OneShot, string? Loop);

/// <summary>
/// What Don wears: a whole costume (full/cos/cos_NNN000) or divided parts (head, body, face paint).
/// Costume 0 is "no costume": the default parts.
/// </summary>
public readonly record struct DonCostume(int? Whole, int Head, int Body, int Paint)
{
    public static DonCostume Default { get; } = new(null, 0, 0, 0);

    /// <summary>Green's dan costume: the renderer draws the model of the wearer's displayed rank.</summary>
    public const int Dan = 36;

    public static DonCostume FromWhole(int id) => id <= 0 ? Default : new(id, 0, 0, 0);
}

/// <summary>
/// A player's Don as their profile has it: costume parts (kigurumi, head, body, face, puchi; 0 = none)
/// and face/body/limb colours as #rrggbb.
/// </summary>
public sealed record DonLook(int[] Costume, string Face, string Body, string Limb)
{
    /// <summary>The entry's three costume sets, [kigurumi, head, body, puchi] each; null: none served.</summary>
    public int[][]? Presets { get; init; }

    /// <summary>The displayed dan rank (0 none, 1-25 Beginner through Tatsujin): which dan costume model to draw.</summary>
    public int DanRank { get; init; }

    public DonCostume ToCostume() => Costume switch
    {
        [> 0 and var whole, ..] => DonCostume.FromWhole(whole),
        [_, var head, var body, var paint, ..] => new DonCostume(null, head, body, paint),
        _ => DonCostume.Default,
    };

    /// <summary>The puchi chara (costume slot 5; 0 = none). A whole costume does not hide it.</summary>
    public int Puchi => Costume is [_, _, _, _, var puchi, ..] ? puchi : 0;

    public (uint Face, uint Body, uint Limb) Colors => (rgb(Face), rgb(Body), rgb(Limb));

    private static uint rgb(string hex) => Convert.ToUInt32(hex.TrimStart('#'), 16);
}

public enum DonPresentationLayout
{
    /// <summary>The second player's Don-chan on the right, the mirrored camera turning them inward (entry, Song Select).</summary>
    Standard,
    /// <summary>The second player's Don-chan unmirrored, facing the same way as the first (results).</summary>
    OpposedPlayers,
    Gameplay,
    Retry,
    RetrySuccess,
    /// <summary>The balloon overlay: a closer menu-style view, the balloon at Don's mouth.</summary>
    Balloon,
    /// <summary>The kusudama overlay: the menu view, both Dons facing the centre.</summary>
    Kusudama,
}

/// <summary>
/// Renderer-facing Don state owned outside Lumen. Implementations advance at the game tick and
/// provide GPU-backed native surfaces to the platform compositor.
/// </summary>
public interface IDonPresentationController
{
    void Reset(DonPresentationLayout layout);

    /// <summary>Changes the view while keeping the current motion.</summary>
    void SetCameraLayout(DonPresentationLayout layout) => Reset(layout);

    /// <summary>Changes one player's view (two-player gameplay: one Don in a balloon, the other playing).</summary>
    void SetCameraLayout(int playerIndex, DonPresentationLayout layout) => SetCameraLayout(layout);

    LumenNativeSurfaceKey GetSurface(int playerIndex);

    void SetMotion(DonMotionRequest request);

    /// <summary>
    /// Changes the loop without interrupting a running one-shot: the one-shot finishes into the
    /// new loop, and an idle that is already looping switches at once.
    /// </summary>
    void SetIdle(int playerIndex, string motionLoop) => SetMotion(new(playerIndex, null, motionLoop));

    /// <summary>Dresses a player's Don; kept across scenes.</summary>
    void SetCostume(int playerIndex, DonCostume costume)
    {
    }

    /// <summary>Dresses and colours a player's Don as their profile has it (null: the default Don).</summary>
    void SetLook(int playerIndex, DonLook? look)
    {
        SetCostume(playerIndex, look?.ToCostume() ?? DonCostume.Default);
        SetAccessory(playerIndex, look?.Puchi ?? 0);
    }

    /// <summary>The puchi chara floating beside a player's Don (0 = none); kept across scenes.</summary>
    void SetAccessory(int playerIndex, int puchi)
    {
    }

    /// <summary>Turns a player's Don model in the gameplay view (degrees; a modchart's). The other views ignore it.</summary>
    void SetModelRotation(int playerIndex, float yaw, float pitch, float roll)
    {
    }

    /// <summary>The entry's card dialog Don (the donExM marker, slot 2): shown while a read card waits for a drum.</summary>
    void SetDialogDon(bool visible)
    {
    }
}

/// <summary>Connects the authored Don fill markers in a Lumen movie to native render targets.</summary>
public static class DonLumenBinding
{
    public static readonly LumenNativeSurfacePlacement Placement =
        LumenNativeSurfacePlacement.Centered(600, 600) with { UniformScale = true };

    /// <param name="player">The movie receiving the native fill markers.</param>
    /// <param name="presentation">The Don presentation supplying render targets.</param>
    /// <param name="layout">The view to use when resetting the presentation.</param>
    /// <param name="reset">False binds the markers without resetting the view and motions (a movie
    /// joining a scene whose Dons are already playing).</param>
    public static void Attach(
        LumenPlayer player,
        IDonPresentationController presentation,
        DonPresentationLayout layout = DonPresentationLayout.Standard,
        bool reset = true)
    {
        ArgumentNullException.ThrowIfNull(player);
        ArgumentNullException.ThrowIfNull(presentation);
        if (reset)
            presentation.Reset(layout);
        player.SetNativeFill("don1pM", presentation.GetSurface(0), Placement);
        player.SetNativeFill("don2pM", presentation.GetSurface(1), Placement);
    }

    public static void RegisterMotion(
        LumenHostContext context,
        LumenHostObject lumen,
        IDonPresentationController presentation,
        string methodName = "SetMotion")
    {
        ArgumentNullException.ThrowIfNull(context);
        ArgumentNullException.ThrowIfNull(lumen);
        ArgumentNullException.ThrowIfNull(presentation);
        lumen.RegisterMethod(methodName, call =>
        {
            ApplyMotion(context, presentation, call.Arguments);
            return LumenHostValue.Undefined;
        });
    }

    /// <summary>(player, one-shot DON_* id, loop DON_* id), resolved through the movie's DON_ constants.</summary>
    public static void ApplyMotion(
        LumenHostContext context,
        IDonPresentationController presentation,
        IReadOnlyList<LumenHostValue> arguments,
        Func<int, string?>? motionFallback = null)
    {
        if (arguments.Count < 3)
            return;
        var player = integer(arguments[0]);
        if (player is not (0 or 1))
            return;
        presentation.SetMotion(new DonMotionRequest(
            player,
            motionName(context, arguments[1], motionFallback),
            motionName(context, arguments[2], motionFallback)));
    }

    /// <summary>
    /// Entry costume picker: ChangeCostume(player, id) / ChangeDivideCostume(player, head, body, paint),
    /// and ChangeAccessory(player, puchi, 0) (traced session27-puchi, after the costume call).
    /// </summary>
    public static void RegisterCostume(LumenHostObject lumen, IDonPresentationController presentation,
        Action<int>? changed = null)
    {
        ArgumentNullException.ThrowIfNull(lumen);
        ArgumentNullException.ThrowIfNull(presentation);
        lumen.RegisterMethod("ChangeCostume", call =>
        {
            if (call.Arguments.Length >= 2 && integer(call.Arguments[0]) is var player and (0 or 1))
            {
                presentation.SetCostume(player, DonCostume.FromWhole(integer(call.Arguments[1])));
                changed?.Invoke(player);
            }
            return LumenHostValue.Undefined;
        });
        lumen.RegisterMethod("ChangeAccessory", call =>
        {
            if (call.Arguments.Length >= 2 && integer(call.Arguments[0]) is var player and (0 or 1))
            {
                presentation.SetAccessory(player, integer(call.Arguments[1]));
                changed?.Invoke(player);
            }
            return LumenHostValue.Undefined;
        });
        lumen.RegisterMethod("ChangeDivideCostume", call =>
        {
            if (call.Arguments.Length >= 4 && integer(call.Arguments[0]) is var player and (0 or 1))
            {
                presentation.SetCostume(player, new DonCostume(null,
                    integer(call.Arguments[1]), integer(call.Arguments[2]), integer(call.Arguments[3])));
                changed?.Invoke(player);
            }
            return LumenHostValue.Undefined;
        });
    }

    private static int integer(LumenHostValue argument)
    {
        if (argument.Kind != LumenHostValueKind.Number)
            throw new ArgumentException("Don player argument must be a number.", nameof(argument));
        var value = argument.AsNumber();
        if (!double.IsFinite(value) || value != Math.Truncate(value) || value < int.MinValue || value > int.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(argument), "Don player argument must be a finite integer.");
        return (int)value;
    }

    private static string? motionName(LumenHostContext context, LumenHostValue value, Func<int, string?>? fallback)
    {
        if (value.Kind != LumenHostValueKind.Number)
            return null;
        var global = context.FindNumericVariableName("DON_", value.AsNumber());
        if (global is null)
        {
            var number = value.AsNumber();
            return fallback is not null && double.IsFinite(number) && number == Math.Truncate(number)
                && number >= int.MinValue && number <= int.MaxValue ? fallback((int)number) : null;
        }
        return $"don_{global[4..].ToLowerInvariant()}"
                .Replace("1p", "1P", StringComparison.Ordinal)
                .Replace("2p", "2P", StringComparison.Ordinal);
    }
}
