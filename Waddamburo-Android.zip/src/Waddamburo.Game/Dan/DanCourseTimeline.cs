using Waddamburo.Catalog;
using Waddamburo.Game.Gameplay;

namespace Waddamburo.Game.Dan;

/// <summary>One song's place in a course's timeline: its next-song card starts at Start, its chart's time zero is
/// Zero, and End is where the next song's card starts.</summary>
public sealed record DanTimelineSong(TimeSpan Start, TimeSpan Zero, TimeSpan End, PlayableChart Chart, TaikoCourse Course);

/// <summary>
/// A course's songs as one chart with the next-song card's time between them, so score, combo, gauge and the
/// replay simply carry across them (traced session30: combo goes on, each song keeps its own score and gauge rates).
/// </summary>
public sealed class DanCourseTimeline
{
    /// <summary>Traced session30: from the card's start to the song's first note, about 6.3 s.</summary>
    public static readonly TimeSpan CardLeadIn = TimeSpan.FromSeconds(6);

    // Longer than the widest window a note can still score in (125.125 ms).
    private static readonly TimeSpan LastHit = TimeSpan.FromMilliseconds(130);

    private DanCourseTimeline(PlayableChart merged, IReadOnlyList<DanTimelineSong> songs) => (Chart, Songs) = (merged, songs);

    public PlayableChart Chart { get; }

    public IReadOnlyList<DanTimelineSong> Songs { get; }

    /// <summary>The charts as authored, routes and all: what identifies and scores them.</summary>
    public IReadOnlyList<(PlayableChart Chart, TaikoCourse Course)> Authored { get; private init; } = [];

    /// <summary>A dan course plays a branched song on its master route, with no checks (official course note counts:
    /// rot42 999 = master, normal 981; uhear2 1134 = master only). A chart without checks is played as it is, and so
    /// is one whose master route has no notes (Nijiiro 2021's medl22: a check, notes on the normal route only, 940 official).</summary>
    public static PlayableChart Played(PlayableChart authored)
    {
        ArgumentNullException.ThrowIfNull(authored);
        var master = authored.OnRoute(ChartBranch.Master);
        return master.HitObjects.Length == 0 && master.LongNotes.Length == 0 ? authored.OnRoute(ChartBranch.Normal) : master;
    }

    public static DanCourseTimeline Merge(IReadOnlyList<(PlayableChart Chart, TaikoCourse Course)> charts)
    {
        ArgumentNullException.ThrowIfNull(charts);
        ArgumentOutOfRangeException.ThrowIfZero(charts.Count);
        var songs = new List<DanTimelineSong>();
        var at = TimeSpan.Zero;
        foreach (var (authored, course) in charts)
        {
            var chart = Played(authored);
            var leadIn = new GameplayTimeline(chart.AuthoredOffset, CardLeadIn).LeadIn;
            songs.Add(new DanTimelineSong(at, at + leadIn, at + leadIn + chart.Duration, chart, course));
            at += leadIn + chart.Duration;
        }
        // Control points must start at time zero: the first song's first ones also cover its card.
        var first = songs[0].Chart;
        return new DanCourseTimeline(new PlayableChart(first.Key, TimeSpan.Zero, at,
            songs.SelectMany(static song => song.Chart.HitObjects.Select(note => note.At(note.StartTime + song.Zero))),
            startAtZero(songs.SelectMany(static song => song.Chart.TimingPoints.Select(point => point.At(point.Time + song.Zero))), first.TimingPoints[0]),
            startAtZero(songs.SelectMany(static song => song.Chart.ScrollPoints.Select(point => point.At(point.Time + song.Zero))), first.ScrollPoints[0]),
            // No Go-Go under a song's card, whatever the last song ended in or this one starts in. A later card's
            // waits out the late hits on the last song's last note, which keep their Go-Go score.
            songs.SelectMany((song, index) => song.Chart.EffectPoints.Select(point => point.At(point.Time + song.Zero))
                .Prepend(new ChartEffectPoint(index == 0 ? song.Start : song.Start + LastHit, false))),
            songs.SelectMany(static song => song.Chart.BarLines.Select(line => line.At(line.Time + song.Zero))),
            songs.SelectMany(static song => song.Chart.LongNotes.Select(note => note.At(note.StartTime + song.Zero, note.EndTime + song.Zero))))
        {
            Segments = [.. songs.Select(static song => new ChartSegment(song.Zero, song.Course, song.Chart))],
        }, songs) { Authored = charts };
    }

    /// <summary>
    /// A play's replay as one per song, each on its song's own time, so each is a normal replay of a normal chart.
    /// The cards' time belongs to the song they lead into. Songs not reached get an empty one.
    /// </summary>
    public IReadOnlyList<TaikoReplay> Split(TaikoReplay replay)
    {
        ArgumentNullException.ThrowIfNull(replay);
        var replays = Songs.Select(static _ => new TaikoReplay()).ToList();
        foreach (var input in replay.Inputs)
        {
            var song = Songs.Count - 1;
            while (song > 0 && input.Time < Songs[song].Start)
                song--;
            replays[song].Add(input.Action, input.Time - Songs[song].Zero);
        }
        return replays;
    }

    private static IEnumerable<T> startAtZero<T>(IEnumerable<T> points, T first) => [first, .. points];
}
