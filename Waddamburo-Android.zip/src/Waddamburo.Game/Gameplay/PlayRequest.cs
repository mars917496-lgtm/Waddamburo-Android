using System.Collections.Immutable;
using Waddamburo.Catalog;

namespace Waddamburo.Game.Gameplay;

public enum LocalPlayerSlot
{
    PlayerOne,
    PlayerTwo,
}

/// <summary>
/// The credit's players by drum (0 left, 1 right): a profile (home account or paired card) or a
/// cardless guest, whose name board reads どんちゃん on the left drum and かっちゃん on the right (traced).
/// </summary>
public static class TaikoGuest
{
    // ponytail: process-wide, set by the shell per credit; every name board and save reads it.
    public static Scores.ScoreProfile?[] Profiles { get; } = new Scores.ScoreProfile?[2];

    /// <summary>The name on a side's boards: the account's public name, else the Don-chan's, else the default.</summary>
    public static string Name(int side) => Profiles[side] is { DisplayName.Length: > 0 } profile ? profile.DisplayName
        : side == 1 ? "かっちゃん" : "どんちゃん";

    /// <summary>The longest official title; the name board is laid out for it (servers may send more).</summary>
    public const int MaxTitleLength = 20;

    public static string Title(int side)
    {
        var title = new System.Globalization.StringInfo(Profiles.ElementAtOrDefault(side)?.Title ?? "");
        return title.LengthInTextElements > MaxTitleLength ? title.SubstringByTextElements(0, MaxTitleLength) : title.String;
    }

    public static int TitlePlate(int side) => Profiles.ElementAtOrDefault(side)?.TitlePlate ?? 0;

    public static int DanRank(int side) => Profiles.ElementAtOrDefault(side)?.DisplayDanRank ?? 0;

    public static bool DanGold(int side) => DanRank(side) > 0 && Profiles.ElementAtOrDefault(side)?.DanGold == true;

    /// <summary>Each drum's last play options, offered again on its next song (a credit starts with none).</summary>
    public static TaikoPlayOptions[] Options { get; } = new TaikoPlayOptions[2];

    /// <summary>Each drum's drum sound (音色, 0-5: SE_GAME_NEIRO_00n), chosen on Song Select's tone board.</summary>
    public static int[] Tones { get; } = new int[2];

    /// <summary>Each drum unlocked Oni (right-rim hits on the course board): it stays shown for the rest of the credit.</summary>
    public static bool[] Mania { get; } = new bool[2];

    /// <summary>
    /// Each drum's last course (0 easy..3 oni) and ★: the by-difficulty panel's 前回あそんだむずかしさ board.
    /// ponytail: kept for the app's run only (the game keeps it on the card).
    /// </summary>
    public static (int Course, int Star)?[] LastCourseStar { get; } = new (int, int)?[2];

    /// <summary>Each drum's last course board (0 easy..3 oni/ura): the course select cursor starts there, as on the cabinet.
    /// Kept for the app's run, or the credit (PlayerSession.Reset clears it with Mania).</summary>
    public static int?[] LastCourse { get; } = new int?[2];

    /// <summary>Green's drum sounds: 太鼓, お祭り, いぬねこ, 豪華な太鼓, ドラム, タンバリン.</summary>
    public const int ToneCount = 6;
}

public sealed record PlayerChartRequest
{
    public PlayerChartRequest(
        LocalPlayerSlot player,
        ChartKey chart,
        CatalogAssetKey chartAsset,
        TaikoCourse course)
    {
        ArgumentNullException.ThrowIfNull(chart);
        ArgumentNullException.ThrowIfNull(chartAsset);
        Player = player;
        Chart = chart;
        ChartAsset = chartAsset;
        Course = course;
    }

    public LocalPlayerSlot Player { get; }

    public ChartKey Chart { get; }

    public CatalogAssetKey ChartAsset { get; }

    public TaikoCourse Course { get; }

    /// <summary>The player's play options (演奏オプション).</summary>
    public TaikoPlayOptions Options { get; init; }
}

/// <summary>
/// Immutable, catalog-revision-pinned input for loading one local play session.
/// It carries provider-owned asset identities; gameplay never receives library paths.
/// </summary>
public sealed record PlayRequest
{
    public PlayRequest(
        long catalogRevision,
        SongKey song,
        CatalogAssetKey? audioAsset,
        IEnumerable<PlayerChartRequest> players)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(catalogRevision);
        ArgumentNullException.ThrowIfNull(song);
        ArgumentNullException.ThrowIfNull(players);
        var materialized = players.ToImmutableArray();
        if (materialized.IsEmpty || materialized.Length > 2)
            throw new ArgumentException("A play request must contain one or two local players.", nameof(players));
        if (materialized.Any(static player => player is null))
            throw new ArgumentException("A play request cannot contain a null player.", nameof(players));
        if (materialized.Select(static player => player.Player).Distinct().Count() != materialized.Length)
            throw new ArgumentException("A local player slot can appear only once.", nameof(players));
        // One player may be either drum (a solo right-drum player is Player Two); two are ordered.
        if (materialized.Length == 2
            && (materialized[0].Player != LocalPlayerSlot.PlayerOne || materialized[1].Player != LocalPlayerSlot.PlayerTwo))
        {
            throw new ArgumentException("Local players must be ordered Player One, then Player Two.", nameof(players));
        }
        if (materialized.Any(player => player.Chart.Song != song))
            throw new ArgumentException("Every selected chart must belong to the requested song.", nameof(players));

        CatalogRevision = catalogRevision;
        Song = song;
        AudioAsset = audioAsset;
        Players = materialized;
    }

    public long CatalogRevision { get; }

    public SongKey Song { get; }

    public CatalogAssetKey? AudioAsset { get; }

    public ImmutableArray<PlayerChartRequest> Players { get; }

    /// <summary>Watch a recorded play of the (one) player's chart instead of playing it (home only).</summary>
    public ReviewRequest? Review { get; init; }

    /// <summary>
    /// The random options' seed (きまぐれ / でたらめ): a replay passes its play's, so its notes come out the
    /// same; null: a fresh one.
    /// </summary>
    public int? Seed { get; init; }
}

/// <summary>
/// A recorded play to watch: its drum inputs (in judgement time) and the input offset it was played with,
/// so its hits show where that player saw them; <paramref name="Player"/>, who played it (shown in their place).
/// </summary>
public sealed record ReviewRequest(IReadOnlyList<TaikoReplayInput> Inputs, TimeSpan InputOffset, Scores.ScoreProfile? Player = null)
{
    /// <summary>The server's id of the play being watched (a downloaded replay): its pause menu can report it.</summary>
    public Guid? PlayId { get; init; }
}

public interface IPlayRequestSink
{
    bool TryRequestPlay(PlayRequest request);
}

/// <summary>Owns the pending Song Select handoff and the request accepted by gameplay.</summary>
public sealed class PlayRequestState : IPlayRequestSink
{
    private readonly object _sync = new();
    private PlayRequest? _pending;
    private PlayRequest? _active;

    public PlayRequest? Pending
    {
        get
        {
            lock (_sync)
                return _pending;
        }
    }

    public PlayRequest? Active
    {
        get
        {
            lock (_sync)
                return _active;
        }
    }

    public bool TryRequestPlay(PlayRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        lock (_sync)
        {
            if (_pending is not null || _active is not null)
                return false;
            _pending = request;
            return true;
        }
    }

    public PlayRequest ActivatePending()
    {
        lock (_sync)
        {
            if (_active is not null)
                throw new InvalidOperationException("A play request is already active.");
            var request = _pending
                ?? throw new InvalidOperationException("No play request is pending.");
            _pending = null;
            _active = request;
            return request;
        }
    }

    public void CancelPending()
    {
        lock (_sync)
            _pending = null;
    }

    public void ClearActive()
    {
        lock (_sync)
            _active = null;
    }
}
