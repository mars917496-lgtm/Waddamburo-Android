using Waddamburo.Lumen.Runtime;

namespace Waddamburo.Game.Gameplay;

/// <summary>What song_info asks the host: genre index and stage (song number in the session).</summary>
/// <param name="Genre">song_info's genreArray index: jpop, anime, vocaloid, doyo, variety, classic, game, namco.</param>
/// <param name="Stage">1-based song number in the credit.</param>
/// <param name="Final">The credit's last song: the stage number shows red.</param>
public readonly record struct TaikoSongInfo(int Genre, int Stage, bool Final = false)
{
    /// <summary>song_info's stage frame: 1-4 white, 5-8 the same numbers red (final).</summary>
    public int StageFrame => Math.Clamp(Stage, 1, 4) + (Final ? 4 : 0);
}

/// <summary>Minimal gameplay host so authored enso movies can run their initialization.</summary>
public sealed class TaikoGameplayHostBinding(Func<TaikoSongInfo>? songInfo = null, Action<string, int>? playCue = null) : ILumenHostBinding
{
    public void Install(LumenHostContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        // AI battle's movies: PlayGhostSound(kind, cue), 0 = SE_AIBTL_ENSO, 1 = VO_AIBTL_ENSO (traced cue for cue);
        // FinishLastSectionEffect as the last section's effect ends.
        context.RegisterObject("Lumen", lumen =>
        {
            lumen.RegisterMethod("PlayGhostSound", call =>
            {
                if (call.Arguments.Length >= 2 && call.Arguments[0].Kind == LumenHostValueKind.Number && call.Arguments[1].Kind == LumenHostValueKind.Number)
                    playCue?.Invoke(call.Arguments[0].AsNumber() == 1 ? "VO_AIBTL_ENSO" : "SE_AIBTL_ENSO", (int)call.Arguments[1].AsNumber());
                return LumenHostValue.Undefined;
            });
            lumen.RegisterMethod("FinishLastSectionEffect", static _ => LumenHostValue.Undefined);
        });
        // A dan course's movies: ExternalInterface CallSE(name, moment), traced SE_GAME 17, 19, 20 for between's card,
        // 16 for dani_enso's requirement that can no longer be met.
        context.RegisterExternalInterfaceCall(call =>
        {
            if (call.Arguments.Length > 2 && call.Arguments[0].Kind == LumenHostValueKind.Text && call.Arguments[0].AsString() == "CallSE"
                && call.Arguments[2].Kind == LumenHostValueKind.Text)
                playCue?.Invoke("SE_GAME", call.Arguments[2].AsString() switch { "Start" => 17, "Close" => 19, "Open" => 20, _ => 16 });
            return LumenHostValue.Undefined;
        });
        // song_info: main.genre.gotoAndStop(genreArray[GetGenrNumber()]), main.stage.gotoAndStop(GetPlayCount()).
        context.RegisterObject("LumenSongInfo", info =>
        {
            info.RegisterMethod("GetGenrNumber", _ => LumenHostValue.FromNumber(songInfo?.Invoke().Genre ?? 0));
            info.RegisterMethod("GetPlayCount", _ => LumenHostValue.FromNumber(songInfo?.Invoke().StageFrame ?? 1));
        });
    }
}
