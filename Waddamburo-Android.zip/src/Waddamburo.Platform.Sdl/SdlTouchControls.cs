namespace Waddamburo.Platform.Sdl;

/// <summary>
/// Where a finger lands on the window (0..1 in both directions, as SDL reports it): a row of buttons
/// along the top left (the layout of the keyboard demo: ESC, F11, TAB, L, Q) and, while a song is
/// being played, the drum across the lower part of the window (left ka, left don, right don, right ka).
/// </summary>
public static class SdlTouchControls
{
    /// <summary>The buttons' layout in the demo's 1280x720 canvas.</summary>
    private const float CanvasWidth = 1280, CanvasHeight = 720, ButtonTop = 17, ButtonBottom = 93;

    /// <summary>The drum's red disc on the 1280x720 stage: its centre and radius (the top of it at y 386).</summary>
    public const float DiscX = 650, DiscY = 780, DiscRadius = 394;

    /// <summary>The band the ka labels cover (the lane) on the 1280x720 stage.</summary>
    public const float KaTop = 160, KaBottom = 380;

    /// <summary>Key: null for F11, which the application handles itself (fullscreen).</summary>
    public readonly record struct TouchButton(string Label, float X, float Width, SdlKeyboardKey? Key);

    public static readonly TouchButton[] Buttons =
    [
        new("ESC", 9, 89, SdlKeyboardKey.Escape),
        new("F11", 117, 85, null),
        new("TAB", 229, 85, SdlKeyboardKey.Tab),
        new("L", 337, 85, SdlKeyboardKey.L),
        new("Q", 435, 85, SdlKeyboardKey.Q),
    ];

    /// <summary>The button under the point, or null.</summary>
    public static TouchButton? ButtonAt(float x, float y)
    {
        if (y * CanvasHeight < ButtonTop || y * CanvasHeight > ButtonBottom)
            return null;
        foreach (var button in Buttons)
            if (x * CanvasWidth >= button.X && x * CanvasWidth <= button.X + button.Width)
                return button;
        return null;
    }

    /// <summary>
    /// Player 1's drum pad under the point, where the screen names it: the red disc is the dons (its left half the left
    /// don, its right half the right don) and the lane band above it the kas (left and right of the window's middle).
    /// Anywhere else: null.
    /// </summary>
    public static SdlKeyboardKey? PadAt(float x, float y)
    {
        if (x < 0 || x > 1 || y < 0 || y > 1)
            return null;
        float stageX = x * CanvasWidth, stageY = y * CanvasHeight;
        var inDisc = (stageX - DiscX) * (stageX - DiscX) + (stageY - DiscY) * (stageY - DiscY) <= DiscRadius * DiscRadius;
        if (inDisc)
            return stageX < DiscX ? SdlInputBindings.Pads[1] : SdlInputBindings.Pads[2];
        if (stageY >= KaTop && stageY <= KaBottom)
            return x < 0.5f ? SdlInputBindings.Pads[0] : SdlInputBindings.Pads[3];
        return null;
    }
}
