using Waddamburo.App.Gameplay;
using Waddamburo.Platform.Sdl.Media;

namespace Waddamburo.App.Audio;

/// <summary>
/// A song: the drums' hit sounds and the game's event cues (combo voices, banners, balloons,
/// kusudama, Waiwai's cut-ins and rare note, the song's end).
/// </summary>
internal sealed class GameplaySounds(SoundBank bank)
{
    /// <summary>Waiwai gameplay plays its own drum tone (traced SE_GAME_NEIRO_100_L/R).</summary>
    // ponytail: Waiwai song select's tone choice (AssignTone / RequestToneSE) is not offered yet.
    public bool Waiwai { get; set; }

    /// <summary>AI battle: AI-don's lane (1) drums in its own tone (traced SE_GAME_NEIRO_AIDON_R).</summary>
    public bool AiBattle { get; set; }

    /// <summary>
    /// Per player (lane 0/1; one player is 0): Don-chan's roll and balloon shout is off, as on normal
    /// and up (the game's rule; only easy keeps it). Every other voice plays on every course.
    /// </summary>
    public bool[] RollVoicesOff { get; set; } = [];

    /// <summary>False: two players' sounds are centred and shared (one of each at a time).</summary>
    public bool Panning { get; set; } = true;

    /// <summary>Each lane's drum sound (音色, 0-5); one player is lane 0.</summary>
    public int[] Tones { get; set; } = [];

    // A drum's hit sounds, in its player's tone: centred for one player; in two-player play the left
    // drum's pan left and the right drum's right (traced session9-2p).
    private string drumBank(int? lane) => (Waiwai ? "SE_GAME_NEIRO_100"
        : AiBattle && lane == 1 ? "SE_GAME_NEIRO_AIDON"
        : $"SE_GAME_NEIRO_{Tones.ElementAtOrDefault(lane ?? 0):000}") + (Panning ? lane : null) switch
    {
        0 => "_L",
        1 => "_R",
        _ => "_C",
    };

    public void PrepareDrums(bool twoPlayers = false)
    {
        // Both sets for two players: panning may be switched in the pause menu.
        foreach (var lane in twoPlayers ? new int?[] { 0, 1, null } : [null])
            foreach (var cue in new[] { 0, 1 })
                bank.Preload(drumBank(lane), cue);
    }

    /// <summary>Silent (the attract's demo play under the menu).</summary>
    public bool Muted { get; set; }

    public void PlayDrum(int? lane, bool don)
    {
        if (!Muted)
            bank.Play(drumBank(lane), don ? 0 : 1, AudioBus.DrumHit, trace: false);
    }

    /// <summary>
    /// <paramref name="lane"/> is null for one player. Two players: 0 left, 1 right; a player's own
    /// cues follow the one-player cue as +1 / +2 (traced session9-2p: combo voice 1/2, banners
    /// 10/11 · 7/8 · 13/14, full-combo voice 154/155, balloon 2, roll voice 158, kusudama miss voice 160/161).
    /// </summary>
    public void Play(int? lane, GameplaySoundEvent sound, int combo = 0)
    {
        if (Muted) return;
        int own(int cue) => lane is { } player && Panning ? cue + 1 + player : cue;
        switch (sound)
        {
            case GameplaySoundEvent.LongNoteStarted:
                if (!RollVoicesOff.ElementAtOrDefault(lane ?? 0))
                    bank.Play("VO_GAME", own(156));
                break;
            case GameplaySoundEvent.BalloonPopped:
                bank.Play("SE_GAME", own(0));
                break;
            case GameplaySoundEvent.KusudamaPopped:
                bank.Play("SE_GAME", 3);
                break;
            case GameplaySoundEvent.KusudamaFailed:
                bank.Play("SE_GAME", 5);
                bank.Play("VO_GAME", own(159));
                break;
            // VO_GAME triplets: 0 = 50 combo, 3k = 100k combo up to 5000 (cue 150).
            case GameplaySoundEvent.Combo:
                bank.Play("VO_GAME", own(combo == 50 ? 0 : combo / 100 * 3));
                break;
            case GameplaySoundEvent.FailBanner:
                bank.Play("SE_GAME", own(9));
                break;
            case GameplaySoundEvent.ClearBanner:
                bank.Play("SE_GAME", own(6));
                break;
            case GameplaySoundEvent.FullComboBanner:
                bank.Play("SE_GAME", own(12));
                bank.Play("VO_GAME", own(153));
                break;
            // Waiwai (traced session11-waiwai): SE_WAIENSO 0 as the song starts, 4 per together
            // section, 2 per solo section.
            // Traced SE_GAME_COLLABO_00 cue 0 / 1 with the rare note: taken as the player who hit it.
            case GameplaySoundEvent.RareHit:
                bank.Play("SE_GAME_COLLABO_00", lane ?? 0);
                break;
            case GameplaySoundEvent.WaiwaiStart:
                bank.Play("SE_WAIENSO", 0);
                break;
            case GameplaySoundEvent.SynchroCutIn:
                bank.Play("SE_WAIENSO", 4);
                break;
            case GameplaySoundEvent.SoloCutIn:
                bank.Play("SE_WAIENSO", 2);
                break;
            case GameplaySoundEvent.SongFinished:
                bank.Play("VO_RESULT", 0);
                bank.Play("SE_GAME", 15);
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(sound));
        }
    }
}
