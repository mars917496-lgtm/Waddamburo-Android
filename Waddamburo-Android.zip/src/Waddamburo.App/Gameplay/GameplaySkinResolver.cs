using System.Text;
using System.Xml.Linq;
using Waddamburo.App.Scenes;
using Waddamburo.Catalog;
using Waddamburo.Formats.Ddp;

namespace Waddamburo.App.Gameplay;

/// <summary>
/// Chooses a song's themed gameplay skin. The game names it per song (musicinfo.xml
/// <c>partsset</c>, "taiko" = the random original mix). Custom charts take the skin of the stock
/// song with the same title; otherwise a genre default (project choice: Vocaloid → miku). A chart's
/// own <see cref="SongDescriptor.ScenePresets"/> come first: a preset names a skin archive, with or
/// without its enso_ prefix, case and punctuation ignored (IMAS_SIDEM, enso_imasSideM). "original"
/// and unknown names give the regular gameplay; archives without the standard parts (dojo, tokkun,
/// waiwai, result, system) are never used. The list: docs/development/gameplay-skins.md.
/// Missing archives and skins without the standard parts fall back to the original mix.
/// </summary>
internal sealed class GameplaySkinResolver
{
    private static readonly Dictionary<string, string> ArchiveNames = new(StringComparer.Ordinal)
    {
        ["GMT"] = "enso_gmt",
        ["butto"] = "enso_buttoburst",
    };
    private static readonly string[] NotStandardSkins = ["taiko", "dojo", "original"];
    // The enso_ archives that are other modes' scenes, not themes (gameplay-skins.md).
    private static readonly string[] NotSkins = ["dojo", "tokkun", "waiwai", "waiwai_effect", "result", "system", "gudetama", "original"];

    private readonly string _lumenRoot;
    private readonly Dictionary<string, string> _partsByTitle = new(StringComparer.Ordinal);
    // By Green's musicid, which Nijiiro shares: its titles are often written differently.
    private readonly Dictionary<string, string> _partsById = new(StringComparer.Ordinal);
    private readonly Dictionary<string, string> _partsByPreset = new(StringComparer.Ordinal);
    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, GameplaySceneComposition.ThemedSkin?> _skins = new(StringComparer.Ordinal);

    /// <param name="lumenRoot">The lumendata/packed directory.</param>
    /// <param name="musicInfos">The musicinfo.xml files, most trusted first: a song takes the first one that lists it.</param>
    public GameplaySkinResolver(string lumenRoot, IEnumerable<string> musicInfos)
    {
        _lumenRoot = lumenRoot;
        if (Directory.Exists(lumenRoot))
            foreach (var directory in Directory.EnumerateDirectories(lumenRoot, "enso_*"))
                _partsByPreset.TryAdd(normalize(Path.GetFileName(directory)["enso_".Length..]), Path.GetFileName(directory)["enso_".Length..]);
        // (Before the aliases below: one name per archive.)
        Names = [.. _partsByPreset.Values.Where(static parts => !NotSkins.Contains(parts, StringComparer.OrdinalIgnoreCase))
            .Order(StringComparer.OrdinalIgnoreCase)];
        foreach (var parts in ArchiveNames.Keys)
            _partsByPreset[normalize(parts)] = parts;
        foreach (var song in musicInfos.Where(File.Exists).SelectMany(static path => XDocument.Load(path).Descendants("Data")))
            if ((string?)song.Element("partsset") is { } parts)
            {
                if ((string?)song.Element("musicname") is { } name)
                    _partsByTitle.TryAdd(normalize(name), parts);
                if (((string?)song.Element("musicid"))?.Trim() is { Length: > 0 } id)
                    _partsById.TryAdd(id, parts);
            }
    }

    /// <summary>
    /// Every revision's musicinfo.xml in <paramref name="dataRoots"/> (the running game's first): each root's
    /// S11100-1 (Green) first, then its older lists newest first (S10100, ST9100 .. ST5100). Songs that rotated
    /// out of Green (171, e.g. fu7bug → funassyi) keep the skin an earlier release gave them.
    /// </summary>
    public static IEnumerable<string> MusicInfos(IEnumerable<string> dataRoots) =>
        dataRoots.SelectMany(static root => Directory.Exists(Path.Combine(root, "config"))
            ? Directory.EnumerateDirectories(Path.Combine(root, "config"))
                .OrderByDescending(static directory => int.TryParse(new string([.. Path.GetFileName(directory).SkipWhile(static c => !char.IsDigit(c)).TakeWhile(char.IsDigit)]), out var number) ? number : -1)
                .ThenBy(static directory => directory, StringComparer.Ordinal)
                .Select(static directory => Path.Combine(directory, "musicinfo.xml"))
            : []);

    /// <summary>The skins the player can choose for every song (the user's enso_ archives that are themes), by name.</summary>
    /// <remarks>ponytail: names only, not checked to load (enso_mh3G is listed, and plays as the regular gameplay).</remarks>
    public IReadOnlyList<string> Names { get; }

    /// <param name="song">The song played (its SCENEPRESET and titles).</param>
    /// <param name="category">Its song select category (Vocaloid's default skin).</param>
    /// <param name="choice">The player's setting (ArcadeSettings.GameplaySkin): "auto", "original" or a skin's
    /// name for every song; a name the data does not have counts as auto.</param>
    public GameplaySceneComposition.ThemedSkin? Resolve(SongDescriptor song, string category, string choice = "auto") =>
        partsFor(song, category, choice) is { } parts
            ? _skins.GetOrAdd($"{ArchiveNames.GetValueOrDefault(parts, "enso_" + parts)}/packeddata.ddp", load)
            : null;

    /// <summary>The song has a skin of its own (by its presets, title or category); nothing is loaded.</summary>
    public bool HasTheme(SongDescriptor song, string category) => partsFor(song, category, "auto") is not null;

    private string? partsFor(SongDescriptor song, string category, string choice)
    {
        if (normalize(choice) == "original")
            return null;
        var parts = lookup(choice)
            ?? song.ScenePresets.Select(lookup).FirstOrDefault(value => value is not null)
            ?? (song.Key.Source is SongSourceKind.Stock or SongSourceKind.Nijiiro ? _partsById.GetValueOrDefault(song.Key.StableId) : null)
            ?? new[] { song.Title.Japanese, song.Title.Primary, song.Title.English }
            .OfType<string>()
            .Select(title => _partsByTitle.GetValueOrDefault(normalize(title)))
            .FirstOrDefault(value => value is not null)
            ?? (normalize(category) is var genre && (genre.Contains("vocaloid") || genre.Contains("ボーカロイド")) ? "miku" : null);
        return parts is null || NotStandardSkins.Contains(parts) ? null : parts;
    }

    // A skin's parts set by any of its names (with or without enso_, case and punctuation ignored).
    private string? lookup(string name)
    {
        var key = normalize(name);
        return _partsByPreset.GetValueOrDefault(key)
            ?? (key.StartsWith("enso", StringComparison.Ordinal) ? _partsByPreset.GetValueOrDefault(key[4..]) : null);
    }

    // A skin is usable when it has the standard parts and every movie loads (enso_mh3G's Don-chan
    // backdrops reference a texture the archive lacks). Checked once per archive, textures not decoded.
    private GameplaySceneComposition.ThemedSkin? load(string archive)
    {
        var path = Path.Combine(_lumenRoot, archive);
        if (!File.Exists(path)) return null;
        var ddp = DdpArchive.Open(File.ReadAllBytes(path));
        var movies = ddp.Index.Movies.Select(movie => movie.Name).ToArray();
        // ponytail: only skins built from the standard parts are wired; others keep the original mix.
        if (!movies.Any(movie => GameplaySceneComposition.Role(Path.GetFileNameWithoutExtension(movie)) == "donbg"))
            return null;
        try
        {
            if (ddp.Index.Movies.Any(movie => Waddamburo.Game.LumenMovieContent.HasErrors(ddp.OpenMovie(movie))))
            {
                Console.Error.WriteLine($"Gameplay skin {archive} has broken movies; using the regular gameplay.");
                return null;
            }
        }
        catch (Exception exception) when (exception is FormatException or InvalidDataException)
        {
            Console.Error.WriteLine($"Gameplay skin {archive} is unreadable ({exception.Message}); using the regular gameplay.");
            return null;
        }
        return new(archive, movies);
    }

    private static string normalize(string text)
    {
        var builder = new StringBuilder();
        foreach (var character in text.Normalize(NormalizationForm.FormKC).ToLowerInvariant())
            if (char.IsLetterOrDigit(character))
                builder.Append(character);
        return builder.ToString();
    }
}
