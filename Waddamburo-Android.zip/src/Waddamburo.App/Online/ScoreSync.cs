using Waddamburo.Game.Flow;
using Waddamburo.Game.Gameplay;
using Waddamburo.Game.Online;
using Waddamburo.Game.Scores;

namespace Waddamburo.App.Online;

/// <summary>
/// The local score database and the TaikOnline side: uploads, server bests, rankings and the
/// cabinet's card pairing. Home keeps every play on this PC (guests' too, baid 0, never uploaded);
/// a cabinet (server and cabinet token set) keeps and uploads everyone's.
/// </summary>
internal sealed class ScoreSync : IDisposable
{
    private readonly ArcadeSettings _arcade;
    private readonly AccountBook? _accounts;
    private readonly Uri? _server;
    private readonly Dictionary<string, ScoreClient> _clients = [];
    private readonly CancellationTokenSource _stopping = new();
    private RealtimeConnection? _realtime;
    private readonly Dictionary<long, NoticeClient> _noticeClients = [];

    private readonly object _onlineLock = new();
    // The home player's account: the one the website shows as online, while the game runs.
    private string? _onlineToken;
    private NoticeClient? _onlineClient;
    private StatusReporter? _statusReporter;

    // accounts: the ones stored on this PC (home mode; null in arcade).
    public ScoreSync(ArcadeSettings arcade, string? scoresPath, AccountBook? accounts)
    {
        _arcade = arcade;
        _accounts = accounts;
        var cabinet = !arcade.Home && arcade is { Server: not null, CabinetToken: not null };
        // A cabinet's indicator also says whether the server takes its token.
        Health = arcade.Server is { } healthServer
            ? new ServerHealth(ScoreClient.CreateHttp(healthServer, arcade.ServerInsecure, arcade.Home ? null : arcade.CabinetToken), cabinet: !arcade.Home)
            : null;
        // ponytail: printed until the notice sidebar draws them.
        Notices.Added += static notice => Console.WriteLine($"Notice [{notice.Severity}] {notice.Message}");
        // A sanction changes the name board (RESTRICTED while banned): show it now, not at the next credit.
        Notices.Added += notice =>
        {
            if (notice.Kind == "sanction")
                RefreshProfiles();
        };
        SetOnlineAccount(accounts?.Default?.Token);
        if (arcade.Server is { } realtimeServer)
            startRealtime(realtimeServer);
        Scores = (arcade.Home || cabinet) && scoresPath is not null ? new ScoreStore(scoresPath) : null;
        rescoreInBackground();
        if (Scores is null || arcade.Server is not { } server)
            return;
        _server = server;
        if (cabinet)
        {
            var http = ScoreClient.CreateHttp(server, arcade.ServerInsecure, arcade.CabinetToken);
            CabinetServer = new ScoreClient(http);
            Pairing = new CabinetPairing(http);
        }
        // Plays left over from offline runs: a cabinet's (everyone's), or each stored account's.
        if (CabinetServer is not null)
            Upload(ScoreProfile.LocalGuest);
        foreach (var account in accounts?.Accounts ?? [])
        {
            Upload(account.Profile);
            RefreshBests(account.Profile);
        }
        RefreshProfiles();
    }

    /// <summary>
    /// Names, looks, titles and avatars as the website has them now, in the background (revoked logins
    /// drop out). At startup and at every credit start, so website changes show by the next entry.
    /// </summary>
    public void RefreshProfiles()
    {
        if (_accounts is not { } accounts || !Online)
            return;
        _ = Task.Run(async () =>
        {
            try
            {
                await accounts.RefreshAsync(account => ClientFor(account.Token)!).ConfigureAwait(false);
            }
            catch (Exception exception) when (exception is HttpRequestException or TaskCanceledException)
            {
                Console.Error.WriteLine($"Warning ACCOUNT: profiles not refreshed ({exception.Message}).");
            }
        });
    }

    /// <summary>The server's notices: for every client, and for the home accounts stored here.</summary>
    public NoticeBoard Notices { get; } = new();

    /// <summary>Background work on this PC (uploads, library hashing), shown with the notices.</summary>
    public JobBoard Jobs { get; } = new();

    /// <summary>The local score database, open when a profile plays (null: guests, nothing saved).</summary>
    public ScoreStore? Scores { get; }

    /// <summary>A cabinet's own server client (its token uploads for every player); null at home.</summary>
    public ScoreClient? CabinetServer { get; }

    /// <summary>A cabinet's 6-digit card pairing (null at home).</summary>
    public CabinetPairing? Pairing { get; }

    /// <summary>The server's reachability, for the network icon (null offline).</summary>
    public ServerHealth? Health { get; }

    /// <summary>Scores go to a server (charts need their hashes to match its bests).</summary>
    public bool Online => _server is not null;

    // Plays kept under older rules (guests' too) are scored again from their replays, as the server does.
    private void rescoreInBackground()
    {
        if (Scores is not { } scores)
            return;
        _ = Task.Run(() =>
        {
            var plays = scores.OutdatedPlays(PlayRecord.CurrentScoringVersion);
            if (plays.Count == 0)
                return;
            var job = Jobs.Start(Strings.T("job.rescore_scores"), plays.Count);
            var charts = new Cli.Rescore.ChartCache();
            var failed = 0;
            for (var index = 0; index < plays.Count; index++)
            {
                job.Report(index);
                var play = plays[index];
                try
                {
                    scores.UpdateScore(play.Id, Cli.Rescore.Score(charts, play.Notes, play.Source, play.Options, play.Seed, play.Replay),
                        PlayRecord.CurrentScoringVersion);
                }
                catch (Exception exception) when (Cli.Rescore.IsBadPlay(exception))
                {
                    // ponytail: kept as it was and tried again next start.
                    failed++;
                    Console.Error.WriteLine($"Warning SCORE_RESCORE: play {play.Id} not rescored ({exception.Message}).");
                }
            }
            job.Complete();
            Console.WriteLine($"Rescored {plays.Count - failed} plays under scoring version {PlayRecord.CurrentScoringVersion}.");
        });
    }

    /// <summary>
    /// Uploads a player's pending plays in the background: a cabinet uploads everyone's with its own
    /// token; a home PC uploads each account's with that account's token (a friend's short-lived one
    /// included). Guests (no token) stay local.
    /// </summary>
    public void Upload(ScoreProfile profile)
    {
        if (Scores is null)
            return;
        if (CabinetServer is { } cabinet)
        {
            cabinet.SyncInBackground(Scores, null, Jobs.Start(Strings.T("job.upload_scores")));
            return;
        }
        if (profile.Token is { } token && ClientFor(token) is { } uploader)
            uploader.SyncInBackground(Scores, profile.Baid, Jobs.Start(Strings.T("job.upload_scores")));
    }

    /// <summary>
    /// Downloads a player's server bests (crowns from every machine) into the store in the background;
    /// song select reads them when it loads. Guests have none.
    /// </summary>
    public void RefreshBests(ScoreProfile profile)
    {
        ArgumentNullException.ThrowIfNull(profile);
        if (Scores is not { } scores || profile.Baid == ScoreProfile.LocalGuestBaid)
            return;
        var client = CabinetServer ?? (profile.Token is { } token ? ClientFor(token) : null);
        if (client is null)
            return;
        long? baid = CabinetServer is null ? null : profile.Baid;
        _ = Task.Run(async () =>
        {
            try
            {
                var (bests, recent) = await client.BestsAsync(baid).ConfigureAwait(false);
                scores.ReplaceRemoteBests(profile.Baid, bests, recent);
            }
            catch (Exception exception) when (exception is HttpRequestException or TaskCanceledException
                or System.Text.Json.JsonException)
            {
                Console.Error.WriteLine($"Warning BESTS: {profile.Name}'s server bests not loaded ({exception.Message}).");
            }
        });
    }

    /// <summary>A server client with a home player's token (one per token, reused); null offline.</summary>
    public ScoreClient? ClientFor(string token)
    {
        if (_server is not { } server)
            return null;
        lock (_clients)
        {
            if (!_clients.TryGetValue(token, out var client))
                _clients[token] = client = new ScoreClient(ScoreClient.CreateHttp(server, _arcade.ServerInsecure, token));
            return client;
        }
    }

    /// <summary>
    /// Rankings are read with the cabinet's token, or at home with any token at hand: a joined
    /// player's, the default account's, then any stored account's.
    /// </summary>
    public ScoreClient? RankingClient() => CabinetServer ?? TaikoGuest.Profiles.Select(static profile => profile?.Token)
        .Append(_accounts?.Default?.Token).Concat(_accounts?.Accounts.Select(static account => account.Token) ?? [])
        .OfType<string>().Select(ClientFor).FirstOrDefault(static client => client is not null);

    /// <summary>
    /// Stays connected to the server's realtime channel (Reverb) for notices: wdb.notices for everyone,
    /// a private channel per stored account. Every (re)connect first loads what is showing and what is
    /// unread, so nothing posted while offline is missed; setup retries each minute while the server
    /// is unreachable. ponytail: accounts added after startup get theirs from the next start; cabinets
    /// get system notices only (their operator view comes later).
    /// </summary>
    private void startRealtime(Uri server)
    {
        var anonymous = new NoticeClient(ScoreClient.CreateHttp(server, _arcade.ServerInsecure));
        var accounts = (_accounts?.Accounts ?? [])
            .Select(account => (Client: new NoticeClient(ScoreClient.CreateHttp(server, _arcade.ServerInsecure, account.Token)), account.Baid))
            .ToArray();
        lock (_noticeClients)
            foreach (var (client, baid) in accounts)
                _noticeClients[baid] = client;
        var personal = new Dictionary<string, (NoticeClient Client, long Baid)>(StringComparer.Ordinal);
        async Task loadBacklogAsync()
        {
            foreach (var notice in await anonymous.NoticesAsync().ConfigureAwait(false))
                Notices.Add(Notice.From(notice, NoticeSource.System));
            foreach (var (client, baid) in accounts)
            {
                // One account's trouble (a revoked token) must not keep the others' or the system notices away.
                try
                {
                    var (channel, backlog) = await client.NotificationsAsync().ConfigureAwait(false);
                    foreach (var notice in backlog)
                        Notices.Add(Notice.From(notice, NoticeSource.Personal, baid));
                    if (channel is not null)
                        lock (personal)
                            personal[channel] = (client, baid);
                }
                catch (HttpRequestException exception)
                {
                    Console.Error.WriteLine($"Warning NOTICES: account {baid}'s notices not loaded ({exception.Message}).");
                }
            }
        }
        (NoticeClient Client, long Baid)? ownerOf(string channel)
        {
            lock (personal)
                return personal.TryGetValue(channel, out var owner) ? owner : null;
        }

        _ = Task.Run(async () =>
        {
            while (!_stopping.IsCancellationRequested)
            {
                try
                {
                    await loadBacklogAsync().ConfigureAwait(false);
                    if (await anonymous.RealtimeAsync(_stopping.Token).ConfigureAwait(false) is not { } url)
                        return; // a server without realtime: the backlog is all there is
                    var realtime = new RealtimeConnection(url, _arcade.ServerInsecure)
                    {
                        Authorize = (socketId, channel, cancellationToken) => ownerOf(channel) is { } owner
                            ? owner.Client.AuthorizeChannelAsync(socketId, channel, cancellationToken)
                            : Task.FromResult<ChannelAuthorization?>(null),
                    };
                    realtime.Received += (channel, name, data) =>
                    {
                        // An admin ended or deleted a system notice: it leaves the board.
                        if (name == "notice-ended" && data.TryGetProperty("id", out var ended) && ended.GetString() is { } endedId)
                        {
                            Notices.Dismiss($"{NoticeSource.System}:{endedId}");
                            return;
                        }
                        // The account's loadout changed on the website: shown from the next scene that dresses Don.
                        if (name == "profile" && ownerOf(channel) is { } changed)
                        {
                            applyProfile(changed.Baid, data);
                            return;
                        }
                        if (name != "notice" || NoticeClient.ParseNotice(data) is not { } notice)
                            return;
                        Notices.Add(ownerOf(channel) is { } owner
                            ? Notice.From(notice, NoticeSource.Personal, owner.Baid)
                            : Notice.From(notice, NoticeSource.System));
                    };
                    realtime.SubscriptionFailed += static channel =>
                        Console.Error.WriteLine($"Warning NOTICES: {channel} refused; retried on the next connection.");
                    var first = true;
                    realtime.ConnectionChanged += connected =>
                    {
                        Console.WriteLine($"Notices: realtime {(connected ? "connected" : "disconnected, reconnecting")}.");
                        if (connected && !first)
                            _ = loadBacklogAsync().ContinueWith(static task => Console.Error.WriteLine(
                                $"Warning NOTICES: {task.Exception?.GetBaseException().Message}"), TaskContinuationOptions.OnlyOnFaulted);
                        first &= !connected;
                    };
                    realtime.Subscribe("wdb.notices");
                    lock (personal)
                        foreach (var channel in personal.Keys)
                            realtime.Subscribe(channel);
                    realtime.Start();
                    _realtime = realtime;
                    return;
                }
                catch (Exception exception) when (exception is HttpRequestException or TaskCanceledException
                    or System.Text.Json.JsonException)
                {
                    if (_stopping.IsCancellationRequested)
                        return;
                    Console.Error.WriteLine($"Warning NOTICES: not connected ({exception.Message}); retrying in a minute.");
                }
                try
                {
                    await Task.Delay(TimeSpan.FromMinutes(1), _stopping.Token).ConfigureAwait(false);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
            }
        });
    }

    /// <summary>A pushed profile: the stored account and any joined player with that baid take it (keeping their token).</summary>
    private void applyProfile(long baid, System.Text.Json.JsonElement data)
    {
        ScoreProfile? current;
        try
        {
            current = ScoreClient.ParseProfile(data);
        }
        catch (System.Text.Json.JsonException exception)
        {
            Console.Error.WriteLine($"Warning ACCOUNT: unreadable profile push ({exception.Message}).");
            return;
        }
        if (current is null || current.Baid != baid)
            return;
        _accounts?.Apply(current);
        // One notice per account, replaced by each push so it shows again (a save can push twice: costume and colours).
        var id = $"{NoticeSource.Personal}:profile:{baid}";
        Notices.Dismiss(id);
        Notices.Add(new Notice(id, NoticeSource.Personal, NoticeSeverity.Info,
            Strings.T("notices.profile_changed"), DateTimeOffset.UtcNow) { Kind = "profile", Baid = baid });
        for (var side = 0; side < TaikoGuest.Profiles.Length; side++)
            if (TaikoGuest.Profiles[side] is { } joined && joined.Baid == baid)
                TaikoGuest.Profiles[side] = joined with { Name = current.Name, Look = current.Look, Avatar = current.Avatar,
                    AccountName = current.AccountName, Title = current.Title, TitlePlate = current.TitlePlate,
                    DanRank = current.DanRank, DanGold = current.DanGold };
    }

    /// <summary>
    /// Reports this account's status from now on, in place of any before it; null (a guest, or no account) reports nothing.
    /// </summary>
    public void SetOnlineAccount(string? token)
    {
        if (_arcade.Server is not { } server)
            return;
        NoticeClient? previous;
        lock (_onlineLock)
        {
            if (token == _onlineToken)
                return;
            _onlineToken = token;
            previous = _onlineClient;
            var client = token is null ? null : new NoticeClient(ScoreClient.CreateHttp(server, _arcade.ServerInsecure, token));
            _onlineClient = client;
            _statusReporter = client is null ? null : new StatusReporter(status => client.SetStatusAsync(status), static () => TimeSpan.FromMilliseconds(Environment.TickCount64));
        }
        _ = clearStatus(previous);
    }

    /// <summary>What the online account is doing, each tick: sent when it changes and now and then otherwise.</summary>
    public void ReportStatus(PlayerStatus status)
    {
        lock (_onlineLock)
            _statusReporter?.Report(status);
    }

    private static async Task clearStatus(NoticeClient? client)
    {
        if (client is null)
            return;
        try
        {
            await client.ClearStatusAsync().ConfigureAwait(false);
        }
        catch (Exception exception) when (exception is HttpRequestException or TaskCanceledException)
        {
            Console.Error.WriteLine($"Warning STATUS: not cleared ({exception.Message}).");
        }
    }

    private NoticeClient? onlineClient()
    {
        lock (_onlineLock)
            return _onlineClient;
    }

    /// <summary>Notices the player has seen: personal ones are marked read on the server (in the background).</summary>
    public void MarkShown(IReadOnlyList<Notice> notices)
    {
        foreach (var group in notices.Where(static notice => notice is { Source: NoticeSource.Personal, Baid: not null, ServerId: not null })
            .GroupBy(static notice => notice.Baid!.Value))
        {
            NoticeClient? client;
            lock (_noticeClients)
                client = _noticeClients.GetValueOrDefault(group.Key);
            if (client is null)
                continue;
            var ids = group.Select(static notice => notice.ServerId!).ToArray();
            _ = client.MarkReadAsync(ids).ContinueWith(static task => Console.Error.WriteLine(
                $"Warning NOTICES: not marked read ({task.Exception?.GetBaseException().Message})."), TaskContinuationOptions.OnlyOnFaulted);
        }
    }

    public void Dispose()
    {
        // Offline now rather than when the server's status runs out; a dead line doesn't hold up closing.
        clearStatus(onlineClient()).Wait(TimeSpan.FromSeconds(1));
        _stopping.Cancel();
        _realtime?.DisposeAsync().AsTask().Wait(TimeSpan.FromSeconds(2));
        _stopping.Dispose();
        Pairing?.Dispose();
        Health?.Dispose();
        Scores?.Dispose();
    }
}
