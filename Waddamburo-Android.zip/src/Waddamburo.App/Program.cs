using Waddamburo.App;
using Waddamburo.App.Cli;
using Waddamburo.App.Flow;
using Waddamburo.App.Hosting;
using Waddamburo.App.Tools;
using Waddamburo.Platform.Sdl;
using Waddamburo.Platform.Sdl.Media;
using Waddamburo.Platform.Sdl.Rendering;

// The normal boot's start (the game folder, its settings, the update check), before the game opens its window: a
// failure there shows the error screen in a window of its own (people launch the game without a console).
var startingUp = false;
try
{
    // TaikOnline's scorer: stdin to stdout, before anything that touches the console, updates or game data.
    if (args is ["--rescore-dan"])
        return Rescore.RunCourses(Console.OpenStandardInput(), Console.OpenStandardOutput());
    if (args is ["--rescore"])
        return Rescore.Run(Console.OpenStandardInput(), Console.OpenStandardOutput());
    ReleaseConsole.Begin();
    if (SelfUpdate.HandOff(ref args))
        return 0;
    var frameLimit = parseFrameLimit(args);
    var tickLimit = parseLimit(args, "--ticks=");
    var seekFrame = parseLimit(args, "--seek-frame=");
    var windowSize = parseWindowSize(args);
    var screenshotPath = parseOption(args, "--screenshot=");
    var callbackInvocations = CallbackInvocation.Parse(args);
    var inputTimeline = InputPulseParser.Parse(args);
    if (screenshotPath is not null)
    {
        if (frameLimit is null && tickLimit is null)
            frameLimit = 1;
        if (frameLimit == 0)
            throw new ArgumentException("--screenshot requires at least one rendered frame.");
    }
    var archivePath = parseOption(args, "--archive=");
    var movieName = parseOption(args, "--movie=");
    var scenePath = parseOption(args, "--scene=");
    var gameDataRoot = parseOption(args, "--game-data=");
    var assetRoot = parseOption(args, "--asset-root=");
    var tjaRoot = parseOption(args, "--tja-root=");
    var fontPath = parseOption(args, "--font=");
    var audioPath = parseOption(args, "--play-audio=");
    var jinglePath = parseOption(args, "--play-jingle=");
    var soundRoot = parseOption(args, "--sound-root=");
    var startSceneOption = parseOption(args, "--start-scene=");
    var login = args.Contains("--login", StringComparer.Ordinal);
    var logout = args.Contains("--logout", StringComparer.Ordinal);
    var exportCharts = parseOption(args, "--export-charts=");
    var autoplay = args.Contains("--autoplay", StringComparer.Ordinal);
    var recordPerformance = args.Contains("--benchmark-record", StringComparer.Ordinal);
    var benchmark = args.Contains("--benchmark", StringComparer.Ordinal) ? BenchmarkMode.Quit
        : args.Contains("--benchmark=restart", StringComparer.Ordinal) ? BenchmarkMode.Restart : BenchmarkMode.Off;
    var startScene = StartSceneParser.Parse(startSceneOption);
    var donRoot = parseOption(args, "--don-root=");
    var previewPath = parseOption(args, "--preview=");
    var soundBankProbe = parseOption(args, "--probe-sound-bank=");
    var syntheticSmoke = args.Contains("--smoke", StringComparer.Ordinal);
    // The cabinet's countdown option (chassisinfo disable_countdowntimer); on by default.
    var countdown = !args.Contains("--no-countdown", StringComparer.Ordinal);
    var positionalRoots = args.Where(static argument => !argument.StartsWith("--", StringComparison.Ordinal)).ToArray();
    if (positionalRoots.Length > 1)
        throw new ArgumentException("Normal boot accepts at most one positional game-data directory.");
    if (gameDataRoot is not null && positionalRoots.Length != 0)
        throw new ArgumentException("Supply the game-data directory either positionally or with --game-data, not both.");
    gameDataRoot ??= positionalRoots.SingleOrDefault();
    if (args.Contains("--preview", StringComparer.Ordinal))
    {
        if (previewPath is not null)
            throw new ArgumentException("Supply --preview or --preview=PATH, not both.");
        previewPath = gameDataRoot ?? GameDataLayout.DefaultRoot();
        gameDataRoot = null;
    }
    if (audioPath is not null && jinglePath is not null)
        throw new ArgumentException("--play-audio and --play-jingle cannot be combined.");
    var entrySongSelect = args.Contains("--entry-song-select", StringComparer.Ordinal);
    var hasDiagnosticContent = entrySongSelect
        || archivePath is not null
        || movieName is not null
        || scenePath is not null
        || assetRoot is not null
        || tjaRoot is not null
        || audioPath is not null
        || jinglePath is not null
        || soundRoot is not null
        || donRoot is not null
        || soundBankProbe is not null
        || previewPath is not null;
    if (syntheticSmoke && (gameDataRoot is not null || hasDiagnosticContent))
        throw new ArgumentException("--smoke cannot be combined with game data or diagnostic content.");
    var normalBoot = !syntheticSmoke && (gameDataRoot is not null || !hasDiagnosticContent);
    if (previewPath is not null)
    {
        if (gameDataRoot is not null || archivePath is not null || movieName is not null || scenePath is not null
            || assetRoot is not null || tjaRoot is not null || audioPath is not null || jinglePath is not null
            || soundRoot is not null || donRoot is not null || soundBankProbe is not null || entrySongSelect
            || startSceneOption is not null || seekFrame is not null || !callbackInvocations.IsEmpty)
            throw new ArgumentException("--preview cannot be combined with game or other content options.");
        ReleaseConsole.Show(true);
        FilePreview.Run(previewPath, windowSize.Width, windowSize.Height, frameLimit, tickLimit, screenshotPath, inputTimeline);
        return 0;
    }
    if (normalBoot)
    {
        if (archivePath is not null || movieName is not null || scenePath is not null
            || assetRoot is not null || tjaRoot is not null || audioPath is not null
            || soundRoot is not null || donRoot is not null || entrySongSelect)
        {
            throw new ArgumentException("--game-data cannot be combined with diagnostic content options.");
        }
        if (seekFrame is not null || !callbackInvocations.IsEmpty)
            throw new ArgumentException("--seek-frame and --invoke are unavailable during normal boot.");

        startingUp = screenshotPath is null && frameLimit is null && tickLimit is null;
        // The update comes first, before anything that could fail (a release that can't start must still be replaced
        // by the next): the settings are read for it if they can be, and read again below to report what's wrong.
        GameDataLayout? early = null;
        Waddamburo.Game.Flow.ArcadeSettings? earlyArcade = null;
        try
        {
            early = GameDataLayout.Resolve(gameDataRoot ?? GameDataLayout.DefaultRoot(), fontPath);
            earlyArcade = Waddamburo.Game.Flow.ArcadeSettings.LoadOrCreate(
                Path.Combine(early.Home, Waddamburo.Game.Flow.ArcadeSettings.FileName));
            Strings.Use(earlyArcade.Language);
        }
        catch (Exception exception) when (exception is not OutOfMemoryException)
        {
        }
        if (startingUp && (earlyArcade?.AutoUpdate ?? true)
            && SelfUpdate.UpdateNow(args, windowSize.Width, windowSize.Height, earlyArcade?.Fullscreen ?? false))
        {
            return 0;
        }
        var layout = early ?? GameDataLayout.Resolve(gameDataRoot ?? GameDataLayout.DefaultRoot(), fontPath);
        ReleaseConsole.CrashFolder = Path.Combine(layout.Home, "logs");
        ReleaseConsole.LogToFile();
        Console.WriteLine($"Game data: {layout.Root}");
        Console.WriteLine($"Title font: {layout.FontPath}");
        Waddamburo.Platform.Sdl.Text.NativeVerticalTextRasterizer.FallbackFonts = layout.FallbackFonts;
        // Cabinet settings (free play, credits, songs per session) beside the game data.
        var arcadePath = Path.Combine(layout.Home, Waddamburo.Game.Flow.ArcadeSettings.FileName);
        var arcade = earlyArcade ?? Waddamburo.Game.Flow.ArcadeSettings.LoadOrCreate(arcadePath);
        // The cache defaults to this PC's user cache (a game on a USB stick must not decode onto it).
        layout.MoveGameCacheTo(layout.Cache(arcade.CacheFolder));
        Console.WriteLine($"Cache: {layout.Cache(arcade.CacheFolder)}");
        Waddamburo.Platform.Sdl.Media.VgmstreamCli.CacheDirectory = layout.AudioCache(arcade.CacheFolder);
        Waddamburo.Platform.Sdl.Media.VgmstreamCli.GameFolder = layout.Root;
        Waddamburo.App.Audio.SongLoudness.CacheFile = Path.Combine(layout.Cache(arcade.CacheFolder), "loudness.tsv");
        // The online test reports on the console, whatever the settings say.
        if (args.Any(static arg => arg.StartsWith("--online-test", StringComparison.Ordinal)))
            ReleaseConsole.OpenForTool();
        else
            ReleaseConsole.Show(arcade.ShowConsole);
        Strings.Use(arcade.Language);
        Waddamburo.Game.SongSelect.SongSelectCatalogView.Japanese = Strings.Language.StartsWith("ja", StringComparison.Ordinal);
        Console.WriteLine($"Language: {Strings.Language}");
        // ponytail: the config reaches BgfxSupport through its env var; the env var itself still wins.
        if (arcade.Renderer is not null && Environment.GetEnvironmentVariable("WADDAMBURO_RENDERER") is null)
            Environment.SetEnvironmentVariable("WADDAMBURO_RENDERER", arcade.Renderer);
        Console.WriteLine(arcade.Home ? $"Settings: {arcadePath} (home mode: free play, endless songs)."
            : $"Cabinet settings: {arcadePath} (arcade, {(arcade.FreePlay ? "free play" : "coin mode")}, "
                + $"{arcade.SongsPerSession} songs per session).");
        // From here the tools report on the console, and the game shows its own errors (BootChecks, CrashScreen).
        startingUp = false;
        // Fills the texture upscale cache ahead of play, with no game window (see TextureCacheBuilder).
        if (args.FirstOrDefault(static arg => arg.StartsWith("--upscale-textures", StringComparison.Ordinal)) is { } upscale)
            return TextureCacheBuilder.Run(layout.UpscaleCache(arcade.CacheFolder), layout.LumenRoot, upscale.Split('=') is [_, var count]
                ? int.Parse(count, System.Globalization.CultureInfo.InvariantCulture)
                : Math.Max(1, Environment.ProcessorCount - 2));
        // One-off: every stock and Nijiiro chart, hashed, for the server to import as ranked (see ChartExport).
        if (exportCharts is not null)
            return ChartExport.Run(Path.GetFullPath(Path.Combine(layout.LumenRoot, "..", "..")), arcade, exportCharts);
        var accounts = Waddamburo.Game.Scores.AccountBook.Load(layout.Home);
        if (login || logout)
            return AccountCommands.Run(arcade, accounts, login);
        if (parseOption(args, "--online-test=") is { } onlineRoom)
            return OnlineTest.Run(arcade, accounts, onlineRoom, Path.Combine(layout.Home, "logs"));
        if (args.Contains("--online-test", StringComparer.Ordinal))
            return OnlineTest.Run(arcade, accounts, null, Path.Combine(layout.Home, "logs"));
        Console.WriteLine(!arcade.Home
            ? arcade is { Server: not null, CabinetToken: not null }
                ? $"Scores: cabinet mode, players log in with a code from {arcade.Server} (cabinet {Waddamburo.App.Online.CabinetPairing.CabinetId})."
                : "Scores: arcade without a cabinet token (not saved)."
            : $"Scores: kept on this PC; {accounts.Accounts.Count} account(s)"
                + (accounts.Default is { } first ? $", {first.Name} joins by default" : "")
                + (arcade.Server is null ? ", offline." : $", uploaded to {arcade.Server}."));
        var exitCode = GameShell.Run(new GameOptions(
            layout.LumenRoot,
            layout.DonRoot,
            windowSize.Width,
            windowSize.Height,
            frameLimit,
            tickLimit,
            screenshotPath,
            inputTimeline,
            layout.TjaRoot,
            layout.FontPath,
            jinglePath,
            layout.SoundRoot,
            countdown,
            startScene,
            arcade,
            arcadePath,
            accounts,
            Path.Combine(layout.Home, Waddamburo.Game.Scores.ScoreStore.FileName),
            autoplay,
            arcade.Fullscreen,
            layout.ServiceFontPath,
            recordPerformance,
            benchmark));
        // Relaunched only now: the old instance has let go of its files (the texture cache, the scores).
        if (GameShell.RestartRequested)
            SelfUpdate.Relaunch([.. args.Where(static argument => !argument.StartsWith("--benchmark", StringComparison.Ordinal)), .. GameShell.RestartArguments]);
        return exitCode; // 1 after the boot's error screen
    }
    // Diagnostic runs always show their output.
    ReleaseConsole.Show(true);
    if (soundBankProbe is not null)
    {
        if (archivePath is not null || movieName is not null || scenePath is not null
            || assetRoot is not null || tjaRoot is not null || audioPath is not null
            || jinglePath is not null || soundRoot is not null || donRoot is not null || entrySongSelect
            || positionalRoots.Length != 0 || startSceneOption is not null)
        {
            throw new ArgumentException("--probe-sound-bank cannot be combined with game or content options.");
        }
        SoundBankProbe.Run(soundBankProbe, windowSize.Width, windowSize.Height, frameLimit, tickLimit, screenshotPath, inputTimeline);
        return 0;
    }
    if (entrySongSelect)
    {
        if (audioPath is not null)
            throw new ArgumentException("--play-audio cannot be combined with --entry-song-select.");
        if (assetRoot is null)
            throw new ArgumentException("--entry-song-select requires --asset-root.");
        if (tjaRoot is null || fontPath is null)
            throw new ArgumentException("--entry-song-select requires --tja-root and --font.");
        if (archivePath is not null || movieName is not null || scenePath is not null)
            throw new ArgumentException("--entry-song-select cannot be combined with movie or scene inputs.");
        if (seekFrame is not null || !callbackInvocations.IsEmpty)
            throw new ArgumentException("--seek-frame and --invoke are unavailable for --entry-song-select.");
        GameShell.Run(new GameOptions(
            assetRoot,
            donRoot,
            windowSize.Width,
            windowSize.Height,
            frameLimit,
            tickLimit,
            screenshotPath,
            inputTimeline,
            tjaRoot,
            fontPath,
            jinglePath,
            soundRoot,
            countdown,
            startScene,
            Autoplay: autoplay));
        return 0;
    }
    if (startSceneOption is not null)
        throw new ArgumentException("--start-scene requires normal boot or --entry-song-select.");
    if (soundRoot is not null)
        throw new ArgumentException("--sound-root currently requires --entry-song-select.");
    if (donRoot is not null)
        throw new ArgumentException("--don-root currently requires --entry-song-select.");
    if (scenePath is not null || assetRoot is not null)
    {
        if (audioPath is not null || jinglePath is not null)
            throw new ArgumentException("Audio diagnostics cannot be combined with --scene.");
        if (scenePath is null || assetRoot is null)
            throw new ArgumentException("--scene and --asset-root must be supplied together.");
        if (archivePath is not null || movieName is not null)
            throw new ArgumentException("Scene options cannot be combined with --archive or --movie.");
        if (seekFrame is not null)
            throw new ArgumentException("--seek-frame currently requires a single --archive/--movie input.");
        if (!callbackInvocations.IsEmpty)
            throw new ArgumentException("--invoke currently requires a single --archive/--movie input.");
        SceneViewer.Run(
            scenePath,
            assetRoot,
            windowSize.Width,
            windowSize.Height,
            frameLimit,
            tickLimit,
            screenshotPath,
            inputTimeline);
        return 0;
    }
    if (archivePath is not null || movieName is not null)
    {
        if (audioPath is not null || jinglePath is not null)
            throw new ArgumentException("Audio diagnostics cannot be combined with --archive/--movie.");
        if (archivePath is null || movieName is null)
            throw new ArgumentException("--archive and --movie must be supplied together.");
        MovieViewer.Run(
            archivePath,
            movieName,
            windowSize.Width,
            windowSize.Height,
            seekFrame,
            frameLimit,
            tickLimit,
            screenshotPath,
            callbackInvocations,
            inputTimeline);
        return 0;
    }
    if (seekFrame is not null)
        throw new ArgumentException("--seek-frame requires --archive and --movie.");
    if (!callbackInvocations.IsEmpty)
        throw new ArgumentException("--invoke requires --archive and --movie.");
    if (!inputTimeline.IsEmpty)
        throw new ArgumentException("--press requires --archive/--movie or --scene/--asset-root.");
    using var application = new SdlApplication(
        "Waddamburo",
        windowSize.Width,
        windowSize.Height,
        debugGpu: false,
        resizable: screenshotPath is null,
        highPixelDensity: screenshotPath is null);
    Console.WriteLine($"Renderer: {application.GpuDriver}");
    using var audioDevice = audioPath is null && jinglePath is null ? null : new SdlAudioDevice();
    using var music = audioPath is null ? null : new StreamingMusicPlayer(audioDevice!, audioPath);
    using var audioEngine = jinglePath is null ? null : new AudioEngine(audioDevice!);
    if (music is not null)
    {
        music.Play();
        Console.WriteLine(
            $"Audio: {Path.GetFileName(audioPath)}, {music.Info.SampleRate} Hz, {music.Info.Channels} channels");
        Console.WriteLine(
            $"SDL audio: {audioDevice!.Driver}, " +
            $"{audioDevice.HardwareFormat.SampleRate} Hz, " +
            $"{audioDevice.HardwareFormat.Channels} channels, " +
            $"{audioDevice.HardwareBufferFrames} buffer frames");
    }
    if (audioEngine is not null)
    {
        var handle = audioEngine.PlayOneShot(jinglePath!, AudioBus.MenuSound);
        Console.WriteLine($"Menu jingle: {Path.GetFileName(jinglePath)}, playback {handle.Value}");
        Console.WriteLine(
            $"SDL audio: {audioDevice!.Driver}, " +
            $"{audioDevice.HardwareFormat.SampleRate} Hz, " +
            $"{audioDevice.HardwareFormat.Channels} channels, " +
            $"{audioDevice.HardwareBufferFrames} buffer frames");
    }
    var checkerboard = createCheckerboard();
    var texture = application.UploadRgba8(8, 8, checkerboard);
    var frame = new RenderFrame(
        RenderColor.Black,
        [RenderQuad.FromRectangles(
            texture,
            new RenderRectangle(0.25f, 0.18f, 0.5f, 0.64f),
            RenderRectangle.Full,
            RenderColor.White,
            RenderColor.Transparent,
            RenderSampling.Nearest)]);
    var result = application.Run(
        _ => frame,
        static () => { },
        frameLimit,
        tickLimit,
        screenshotPath is null ? null : capture => ScreenshotWriter.Write(screenshotPath, capture));
    reportTiming(result);
    return 0;
}

catch (Exception exception)
{
    if (startingUp)
    {
        Console.Error.WriteLine(exception.Message);
        if (CrashScreen.ShowAlone(exception, ReleaseConsole.WriteCrashFile(exception)))
            return 1;
    }
    ReleaseConsole.Fail(exception);
    return 1;
}

static byte[] createCheckerboard()
{
    var pixels = new byte[8 * 8 * 4];
    for (var y = 0; y < 8; y++)
    {
        for (var x = 0; x < 8; x++)
        {
            var bright = ((x / 2) + (y / 2)) % 2 == 0;
            var offset = (y * 8 + x) * 4;
            pixels[offset] = bright ? (byte)246 : (byte)32;
            pixels[offset + 1] = bright ? (byte)156 : (byte)92;
            pixels[offset + 2] = bright ? (byte)58 : (byte)154;
            pixels[offset + 3] = 255;
        }
    }
    return pixels;
}

static int? parseFrameLimit(string[] arguments)
    => parseLimit(arguments, "--frames=");

static (int Width, int Height) parseWindowSize(string[] arguments)
{
    const string prefix = "--window-size=";
    var option = arguments.SingleOrDefault(argument => argument.StartsWith(prefix, StringComparison.Ordinal));
    if (option is null)
        return (1280, 720);
    var value = option.AsSpan(prefix.Length);
    var separator = value.IndexOfAny('x', 'X');
    if (separator <= 0 || separator == value.Length - 1
        || !int.TryParse(value[..separator], out var width)
        || !int.TryParse(value[(separator + 1)..], out var height)
        || width <= 0 || height <= 0)
    {
        throw new ArgumentException("--window-size must use positive integer WIDTHxHEIGHT dimensions.");
    }
    return (width, height);
}

static int? parseLimit(string[] arguments, string prefix)
{
    var option = arguments.SingleOrDefault(argument => argument.StartsWith(prefix, StringComparison.Ordinal));
    if (option is null)
        return null;
    return int.TryParse(option.AsSpan(prefix.Length), out var value) && value >= 0
        ? value
        : throw new ArgumentException($"{prefix[..^1]} must be a non-negative integer.");
}

static void reportTiming(SdlRunResult result)
{
    if (result.DroppedTicks > 0)
        Console.Error.WriteLine($"Warning PLT_DROPPED_TICKS: dropped {result.DroppedTicks} simulation ticks.");
}

static string? parseOption(string[] arguments, string prefix)
{
    var option = arguments.SingleOrDefault(argument => argument.StartsWith(prefix, StringComparison.Ordinal));
    if (option is null)
        return null;
    var value = option[prefix.Length..];
    return value.Length > 0 ? value : throw new ArgumentException($"{prefix} requires a value.");
}
