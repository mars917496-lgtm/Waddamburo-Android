using Waddamburo.App.Scenes;
using Waddamburo.Game.Flow;
using Waddamburo.Lumen.Runtime;
using Waddamburo.Platform.Sdl.Media;

namespace Waddamburo.App.Flow;

/// <summary>
/// The entry (player join): plays its jingle; the movie itself requests Song Select, which the shell
/// applies once the last voice has finished.
/// </summary>
internal sealed class EntryFlow(GameShell shell) : FlowScene(shell)
{
    private readonly string? _jingle = shell.Options.JinglePath ?? shell.FindJingle("JINGLE_ENTRY.nub");
    private AudioPlaybackHandle? _bgm;

    public override IndicatorScene IndicatorsFor(SceneId scene) => IndicatorScene.Entry;

    public override void Enter(SceneId scene)
    {
        // Song Select comes next: its ~1,400 textures decode and upload in the background meanwhile
        // (loading it at the switch froze the game ~0.7 s). Its movies are the same for either side.
        Shell.Scenes.Prefetch(FlowScenes.SongSelectScene([0]));
        if (_jingle is null || Shell.Audio is not { } audio)
            return;
        // --play-jingle plays it once (a sync check); the scene itself loops it.
        _bgm = Shell.Options.JinglePath is null ? audio.PlayLoop(_jingle, AudioBus.Bgm) : audio.PlayOneShot(_jingle, AudioBus.Bgm);
    }

    public override void Exit(SceneId scene)
    {
        if (_bgm is { } bgm)
            Shell.Audio?.Mixer.Stop(bgm, TimeSpan.FromMilliseconds(20));
        _bgm = null;
    }

    public override void Advance(LumenInputSnapshot input)
    {
        Shell.Active.Player.Advance(input);
        Shell.Hosts.AdvanceEntry();
        Shell.DonRenderer?.Advance();
    }
}
