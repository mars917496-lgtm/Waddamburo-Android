using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.Text.RegularExpressions;
using Waddamburo.Formats.Audio;
using Waddamburo.Lumen.Rendering;
using Waddamburo.Platform.Sdl;
using Waddamburo.Platform.Sdl.Media;
using Waddamburo.Platform.Sdl.Rendering;

namespace Waddamburo.App.Presentation;

/// <summary>
/// One attract CM (data/movie/attract_cm_###.pam) played into attract/movie.lm's video fill.
/// Frames decode on a worker thread and are shown by the CM's own audio clock.
/// </summary>
internal sealed partial class AttractMovie : IDisposable
{
    public static readonly LumenNativeSurfaceKey Surface = new("attract-movie");
    private const int QueuedFrames = 4;

    private readonly SdlApplication _application;
    private readonly AudioEngine? _audio;
    private readonly NativeVideoDecoder _decoder;
    private readonly BlockingCollection<(byte[] Pixels, TimeSpan Time)> _frames = new(QueuedFrames);
    private readonly ConcurrentBag<byte[]> _spare = [];
    private readonly CancellationTokenSource _stop = new();
    private readonly Thread _worker;
    private readonly AudioStreamTransport? _transport;
    private readonly TimeSpan _lead;
    private readonly Stopwatch _clock = Stopwatch.StartNew();
    private readonly TimeSpan _duration;
    private (byte[] Pixels, TimeSpan Time)? _next;
    private volatile bool _decoded;

    /// <summary>
    /// A CM opened and ready to start: its video decoder and its audio track, buffered. The slow part (the
    /// decoder, pulling the track out of the .pam, buffering it: ~0.9 s on a Celeron) runs on a worker
    /// (<see cref="Prepare"/>); <see cref="AttractMovie(SdlApplication, AudioEngine?, Prepared)"/> then starts it at once.
    /// </summary>
    public sealed class Prepared(string path, NativeVideoDecoder decoder, BufferedAudioSource? audio, TimeSpan lead) : IDisposable
    {
        public string Path { get; } = path;
        internal NativeVideoDecoder Decoder { get; } = decoder;
        internal BufferedAudioSource? Audio { get; private set; } = audio;
        internal TimeSpan Lead { get; } = lead;
        // The audio passes to the playing movie (its transport disposes it); this no longer does.
        internal BufferedAudioSource? TakeAudio()
        {
            var taken = Audio;
            Audio = null;
            return taken;
        }

        /// <summary>A prepared CM that will not play (the credit started first).</summary>
        public void Dispose()
        {
            Audio?.Dispose();
            Decoder.Dispose();
        }
    }

    /// <summary>Opens a CM on a worker: <paramref name="format"/> is the mixer's (null: no audio).</summary>
    public static Task<Prepared> Prepare(string path, SdlAudioFormat? format) => Task.Run(() =>
    {
        var decoder = new NativeVideoDecoder(path);
        try
        {
            if (format is not { } mixer)
                return new Prepared(path, decoder, null, TimeSpan.Zero);
            PamfAudio? track;
            using (var file = File.OpenRead(path))
                track = PamfAudio.Extract(file);
            if (track is null)
                return new Prepared(path, decoder, null, TimeSpan.Zero);
            var source = new BufferedAudioSource(new MemoryStream(track.Riff), mixer);
            source.Ready.GetAwaiter().GetResult();
            return new Prepared(path, decoder, source, track.Lead);
        }
        catch
        {
            decoder.Dispose();
            throw;
        }
    });

    /// <summary>Starts a prepared CM (main thread): its texture, its decoding thread, its audio.</summary>
    public AttractMovie(SdlApplication application, AudioEngine? audio, Prepared movie)
    {
        _application = application;
        _audio = audio;
        _decoder = movie.Decoder;
        _duration = _decoder.Duration ?? TimeSpan.Zero;
        Texture = application.UploadRgba8(_decoder.Width, _decoder.Height, new byte[_decoder.Width * _decoder.Height * 4]);
        _worker = new Thread(decode) { IsBackground = true, Name = "Attract movie decoder" };
        _worker.Start();
        if (audio is not null && movie.TakeAudio() is { } source)
        {
            _lead = movie.Lead;
            _transport = audio.PlayTransport(new ScheduledAudioSource(source, TimeSpan.Zero, _duration + _lead));
        }
        Console.WriteLine($"Attract movie {System.IO.Path.GetFileName(movie.Path)}: {_decoder.Width}x{_decoder.Height}, {_duration.TotalSeconds:0.##} s.");
    }

    public RenderTextureId Texture { get; }

    public bool Finished { get; private set; }

    public RenderTextureId? Resolve(LumenNativeSurfaceKey surface) => surface == Surface ? Texture : null;

    /// <summary>Shows the newest frame due by the movie clock.</summary>
    public void Advance()
    {
        var now = (_transport is not null ? _audio!.GetPosition(_transport) : _clock.Elapsed) - _lead;
        byte[]? shown = null;
        while (true)
        {
            if (_next is null)
            {
                if (!_frames.TryTake(out var frame))
                    break;
                _next = frame;
            }
            if (_next.Value.Time > now)
                break;
            if (shown is not null)
                _spare.Add(shown);
            shown = _next.Value.Pixels;
            _next = null;
        }
        if (shown is not null)
        {
            _application.UpdateRgba8(Texture, _decoder.Width, _decoder.Height, shown);
            _spare.Add(shown);
        }
        Finished = _decoded && _next is null && _frames.Count == 0 && now >= _duration;
    }

    private void decode()
    {
        try
        {
            var size = (int)(_decoder.Width * _decoder.Height * 4);
            while (!_stop.IsCancellationRequested)
            {
                var pixels = _spare.TryTake(out var reused) ? reused : new byte[size];
                if (!_decoder.TryReadFrame(pixels, out var time))
                    break;
                _frames.Add((pixels, time), _stop.Token);
            }
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception exception) when (exception is IOException or NotSupportedException)
        {
            Console.Error.WriteLine($"Attract movie decoding stopped: {exception.Message}");
        }
        _decoded = true;
    }

    public void Dispose()
    {
        _stop.Cancel();
        _worker.Join();
        if (_transport is not null)
            _audio!.Mixer.Stop(_transport.Handle, TimeSpan.FromMilliseconds(20));
        _decoder.Dispose();
        _application.ReleaseTexture(Texture);
        _frames.Dispose();
        _stop.Dispose();
    }

    /// <summary>
    /// The CMs the game can pick: attract_cm_###.pam, nonzero ids in order, or the 000 fallback
    /// when there are none. ponytail: the cabinet only plays ids its server permitted
    /// (updates/.../moviepermission.bin); with no server every CM is permitted, as the local
    /// server's default does.
    /// </summary>
    public static string[] Discover(string movieDirectory)
    {
        if (!Directory.Exists(movieDirectory))
            return [];
        var movies = Directory.EnumerateFiles(movieDirectory, "attract_cm_*.pam")
            .Select(path => (path, match: CmName().Match(Path.GetFileName(path))))
            .Where(entry => entry.match.Success)
            .OrderBy(entry => int.Parse(entry.match.Groups[1].Value, CultureInfo.InvariantCulture))
            .ToArray();
        var permitted = movies.Where(entry => entry.match.Groups[1].Value != "000").Select(entry => entry.path).ToArray();
        return permitted.Length != 0 ? permitted : movies.Select(entry => entry.path).ToArray();
    }

    /// <summary>
    /// The opening movie (data/movie/OP.pam) when it is the title: releases whose title.lm still
    /// speaks the old Command("BGMPlay") protocol play OP.pam (with its own audio) in the title's
    /// slot instead. Green ships OP.pam too, but its title.lm replaced it.
    /// </summary>
    public static string? Opening(string movieDirectory, string titleArchive)
    {
        var path = Path.Combine(movieDirectory, "OP.pam");
        // ponytail: raw byte search; LMB string pools are plain UTF-8.
        return File.Exists(path) && File.Exists(titleArchive)
            && File.ReadAllBytes(titleArchive).AsSpan().IndexOf("BGMPlay"u8) >= 0 ? path : null;
    }

    [GeneratedRegex("^attract_cm_([0-9]{3})\\.pam$", RegexOptions.IgnoreCase)]
    private static partial Regex CmName();
}
