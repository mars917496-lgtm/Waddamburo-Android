using System.Collections.Concurrent;
using System.Globalization;
using Waddamburo.Game.Flow;
using Waddamburo.Game.Online;
using Waddamburo.Platform.Sdl.Rendering;
using static Waddamburo.App.Strings;

namespace Waddamburo.App.Presentation;

/// <summary>
/// The notices, after osu!'s notification overlay: new ones pop up as toasts at the top right (held
/// back while a lane is on screen, so a song is never covered), and F8 opens a sidebar listing them
/// with the background jobs on top. The <c>shown</c> callback hears of each notice once the player could
/// have read it (personal ones are then marked read on the server).
/// </summary>
internal sealed class NoticeOverlay : IDisposable
{
    private const float Stage = OverlayPainter.StageWidth, StageHeight = OverlayPainter.StageHeight;
    private const float PanelWidth = 420, CardWidth = 388, Gap = 10, Margin = 16;
    private const float ToastTop = 12;
    private const int MaxToasts = 3, MaxLines = 6, FontSize = 20, LineHeight = 24;
    private static readonly TimeSpan ToastTime = TimeSpan.FromSeconds(6);
    private static readonly TimeSpan Fade = TimeSpan.FromMilliseconds(400);

    private readonly OverlayPainter _painter;
    private readonly NoticeBoard _notices;
    private readonly JobBoard _jobs;
    private readonly Func<long, string?> _playerName;
    private readonly Action<IReadOnlyList<Notice>> _shown;
    private readonly ConcurrentQueue<Notice> _arrived = new();
    private readonly List<(Notice Notice, DateTimeOffset Since)> _toasts = [];
    private readonly HashSet<string> _reported = [];

    public NoticeOverlay(OverlayPainter painter, NoticeBoard notices, JobBoard jobs,
        Func<long, string?> playerName, Action<IReadOnlyList<Notice>> shown)
    {
        _painter = painter;
        _notices = notices;
        _jobs = jobs;
        _playerName = playerName;
        _shown = shown;
        notices.Added += _arrived.Enqueue;
        // Notices that arrived before the overlay existed (the backlog loads while the game starts).
        foreach (var notice in notices.Current.Reverse())
            _arrived.Enqueue(notice);
    }

    public bool Open { get; private set; }

    public void Toggle()
    {
        Open = !Open;
        if (Open)
            lock (_toasts)
                _toasts.Clear(); // the sidebar lists them
    }

    /// <summary><paramref name="onLane"/>: a song or the calibration is on screen; nothing is drawn and toasts wait.</summary>
    public IEnumerable<RenderQuad> Quads(bool onLane)
    {
        if (onLane)
            return [];
        var now = DateTimeOffset.UtcNow;
        var quads = new List<RenderQuad>();
        if (Open)
        {
            while (_arrived.TryDequeue(out _))
            {
            }
            sidebar(quads);
            return quads;
        }
        lock (_toasts)
        {
            _toasts.RemoveAll(toast => now - toast.Since > ToastTime);
            while (_toasts.Count < MaxToasts && _arrived.TryDequeue(out var notice))
                _toasts.Add((notice, now));
            var y = ToastTop;
            foreach (var (notice, since) in _toasts)
            {
                var left = now - since;
                var alpha = (float)Math.Clamp(Math.Min(left / Fade, (ToastTime - left) / Fade), 0, 1);
                // Slides in from the right edge.
                var height = card(quads, notice, Stage - Margin - CardWidth + (1 - alpha) * 40, y, alpha);
                y += height + Gap;
            }
            report(_toasts.Select(static toast => toast.Notice));
        }
        return quads;
    }

    private void sidebar(List<RenderQuad> quads)
    {
        var x = Stage - PanelWidth;
        quads.Add(_painter.Rect(0, 0, Stage, StageHeight, new RenderColor(0, 0, 0, 0.35f)));
        quads.Add(_painter.Rect(x, 0, PanelWidth, StageHeight, new RenderColor(0.07f, 0.07f, 0.09f, 0.94f)));
        quads.Add(_painter.Text(T("notices.title"), x + Margin, 35, PanelWidth - 2 * Margin, 30, anchor: 0));
        quads.Add(_painter.Text(T("notices.close_hint", Waddamburo.App.Flow.GameActions.Name(Waddamburo.App.Flow.GameAction.Notices)), Stage - Margin, 37, PanelWidth - 2 * Margin, 18, anchor: 1));
        var y = 70f;

        foreach (var job in _jobs.Visible)
        {
            var title = job.Failure is { } failure ? T("job.failed", job.Title, failure) : job.Title;
            quads.Add(_painter.Text(title, x + Margin, y + 9, CardWidth, 18, anchor: 0));
            y += 18 + 4;
            quads.Add(_painter.Rect(x + Margin, y, CardWidth, 6, new RenderColor(1, 1, 1, 0.15f)));
            var colour = job.Failure is not null ? new RenderColor(0.9f, 0.3f, 0.25f, 1) : new RenderColor(0.35f, 0.7f, 1, 1);
            // No count: a block sweeping across the bar.
            var (from, width) = job.Fraction is { } fraction
                ? (0f, (float)fraction * CardWidth)
                : ((float)(DateTimeOffset.UtcNow - job.StartedAt).TotalSeconds % 1.5f / 1.5f * (CardWidth - 80), 80f);
            quads.Add(_painter.Rect(x + Margin + from, y, job.EndedAt is null || job.Failure is not null ? width : CardWidth, 6, colour));
            y += 6 + Gap * 1.5f;
        }

        var notices = _notices.Current;
        if (notices.Count == 0)
        {
            quads.Add(_painter.Text(T("notices.empty"), x + Margin + CardWidth / 2, y + 20 + FontSize / 2f, CardWidth, FontSize, alpha: 0.6f));
            return;
        }
        var shown = new List<Notice>();
        foreach (var notice in notices)
        {
            if (y + cardHeight(notice) > StageHeight - Margin)
                break; // ponytail: no scrolling; the oldest that do not fit are not drawn
            var height = card(quads, notice, x + Margin, y);
            shown.Add(notice);
            y += height + Gap;
        }
        report(shown);
    }

    // Tells the owner once per notice that it was on screen.
    private void report(IEnumerable<Notice> notices)
    {
        var fresh = notices.Where(notice => _reported.Add(notice.Id)).ToList();
        if (fresh.Count > 0)
            _shown(fresh);
    }

    private static List<string> lines(Notice notice) => TextWrap.Lines(notice.Message, (CardWidth - 36) / (FontSize * 0.5f), MaxLines);

    private static int cardHeight(Notice notice) => 16 + 20 + lines(notice).Count * LineHeight + 12;

    // One notice as a card: a severity stripe, where it came from, and the message wrapped. Returns its height.
    private float card(List<RenderQuad> quads, Notice notice, float x, float y, float alpha = 1)
    {
        var height = cardHeight(notice);
        quads.Add(_painter.Canvas(("notice", notice.Id), x, y, CardWidth, height, canvas =>
        {
            var text = lines(notice);
            canvas.RoundedRect(0, 0, CardWidth, height, 8, (32, 33, 40), outline: 1.5f, outlineColour: (70, 72, 84));
            canvas.RoundedRect(6, 8, 5, height - 16, 2.5f, notice.Severity switch
            {
                NoticeSeverity.Critical => (235, 72, 60),
                NoticeSeverity.Warning => (245, 180, 40),
                _ => (90, 170, 255),
            }, outline: 0);
            var source = notice.Source switch
            {
                NoticeSource.Personal when notice.Baid is { } baid && _playerName(baid) is { } name => T("notices.source.player", name),
                NoticeSource.Local => T("notices.source.local"),
                _ => T("notices.source.server"),
            };
            // ICU puts a narrow no-break space before AM/PM, which the game font lacks.
            var at = notice.At.ToLocalTime().ToString("t", CultureInfo.CurrentCulture).Replace('\u202F', ' ');
            canvas.Text($"{source} · {at}", 22, 16 + 9, CardWidth - 36, 16, anchorX: 0, tint: (170, 175, 190));
            for (var line = 0; line < text.Count; line++)
                canvas.Text(text[line], 22, 16 + 20 + line * LineHeight + LineHeight / 2f, CardWidth - 36, FontSize, anchorX: 0);
        }, alpha));
        return height;
    }

    public void Dispose() => _notices.Added -= _arrived.Enqueue;
}
