using System.Collections.Concurrent;
using Waddamburo.Platform.Sdl;
using Waddamburo.Platform.Sdl.Rendering;

namespace Waddamburo.App.Presentation;

/// <summary>
/// Live upscaling while the game runs: every uploaded movie texture is queued, newest first, and
/// upscaled one at a time on the threads set in upscale_threads (none by default), holding during
/// gameplay and bakes. Cached results arrive at once; each replaces its texture in place (UVs are normalised).
/// A batch run (--upscale-textures) fills the cache ahead with more threads.
/// </summary>
internal sealed class TextureUpscaler : IDisposable
{
    // The pixels are decoded when the job runs (a texture kept compressed); the key, when the index knew it.
    private sealed record Job(RenderTextureId Texture, uint Width, uint Height, Func<byte[]> Pixels, string? Key)
    {
        private UpscaleSource? _source;
        public UpscaleSource Source => _source ??= new UpscaleSource(Width, Height, Pixels());
        public string CacheKey => Key ?? UpscaleTool.Key(Source);
    }
    private readonly record struct Result(RenderTextureId Texture, UpscaledTexture Upscaled);

    // Newest first: the scene on screen before the ones left behind (those still fill the cache).
    // ponytail: queued jobs keep their pixels (or a compressed texture's blocks, a quarter of that) alive;
    // re-read from the archive if memory matters.
    private readonly ConcurrentStack<Job> _jobs = new();
    private readonly ConcurrentStack<Job> _misses = new();
    private readonly ConcurrentQueue<Result> _done = new();
    private readonly SemaphoreSlim _jobWake = new(0);
    private readonly SemaphoreSlim _missWake = new(0);
    private readonly CancellationTokenSource _stop = new();
    private readonly UpscaleTool _tool;
    private readonly Func<Waddamburo.Game.Flow.ArcadeSettings> _settings;
    private readonly Thread _loader;
    private readonly Thread _upscaler;
    private volatile bool _paused;

    /// <remarks><paramref name="settings"/>: upscale_textures (queue anything at all) and upscale_threads (0: none
    /// upscaled in the background), read live.</remarks>
    public TextureUpscaler(UpscaleTool tool, Func<Waddamburo.Game.Flow.ArcadeSettings> settings)
    {
        _tool = tool;
        _settings = settings;
        // Two threads: cached results load at once, even during gameplay, while only the
        // upscaling of misses holds (an upscale caught mid-way must not keep the cache waiting).
        _loader = new Thread(load) { IsBackground = true, Name = "Upscaled texture loader", Priority = ThreadPriority.BelowNormal };
        _upscaler = new Thread(upscale) { IsBackground = true, Name = "Texture upscaler", Priority = ThreadPriority.BelowNormal };
        _loader.Start();
        _upscaler.Start();
    }

    /// <summary>Holds new upscaling (gameplay: the CPU belongs to the song); cached textures still load.</summary>
    public bool Paused
    {
        get => _paused;
        set
        {
            if (_paused == value) return;
            _paused = value;
            if (!value) _missWake.Release();
        }
    }

    /// <summary>Whether a texture this size would be queued (upscaling on; tiny ones, dots and fills, gain nothing).</summary>
    public bool Wants(uint width, uint height) => _settings().UpscaleTextures && width * height >= 256;

    /// <summary>Whether these pixels are an upscaled copy (they are never queued).</summary>
    public bool IsUpscaled(byte[] rgba) => _tool.IsUpscaled(rgba);

    /// <summary>
    /// Queues a freshly uploaded original texture; <paramref name="pixels"/> gives pixels that must not change
    /// afterwards (decoded on the loader thread), <paramref name="key"/> its cache name when known.
    /// </summary>
    public void Enqueue(RenderTextureId texture, uint width, uint height, Func<byte[]> pixels, string? key)
    {
        if (!Wants(width, height))
            return;
        _jobs.Push(new Job(texture, width, height, pixels, key));
        _jobWake.Release();
    }

    /// <summary>
    /// Swaps finished textures in (main thread, once per frame), up to about 16 MB of BC7 a frame:
    /// a few big textures in one frame stall it.
    /// </summary>
    public void Apply(SdlApplication application)
    {
        const long Budget = 16 << 20;
        long bytes = 0;
        while (bytes < Budget && _done.TryDequeue(out var result))
        {
            var (texture, upscaled) = result;
            if (application.SupportsBc7)
                application.TryReplaceBc7(texture, upscaled.Width, upscaled.Height, upscaled.Bc7.Span);
            else
                application.TryReplaceRgba8(texture, upscaled.Width, upscaled.Height,
                    Bc7.Decode(upscaled.Bc7.Span, (int)upscaled.Width, (int)upscaled.Height));
            bytes += upscaled.Bc7.Length;
        }
    }

    // Cache hits go straight to the swap queue; misses go to the upscaler.
    private void load()
    {
        while (wait(_jobWake))
            while (!_stop.IsCancellationRequested && _jobs.TryPop(out var job))
                guard(() =>
                {
                    if (_tool.Load(job.CacheKey) is { } upscaled)
                        _done.Enqueue(new Result(job.Texture, upscaled));
                    else
                    {
                        _misses.Push(job);
                        _missWake.Release();
                    }
                });
    }

    // Every second at least: the thread count may have been turned up from off meanwhile.
    private void upscale()
    {
        while (wait(_missWake, TimeSpan.FromSeconds(1)))
            while (!_paused && threads() > 0 && !_stop.IsCancellationRequested && _misses.TryPop(out var job))
                guard(() =>
                {
                    var key = job.CacheKey;
                    if (!_tool.IsCached(key))
                        _tool.Upscale(job.Source, Math.Max(1, threads()), () => _paused && !_stop.IsCancellationRequested);
                    if (_tool.Load(key) is { } upscaled)
                        _done.Enqueue(new Result(job.Texture, upscaled));
                });
    }

    private int threads() => _settings().UpscaleThreads;

    private bool wait(SemaphoreSlim wake, TimeSpan? timeout = null)
    {
        try
        {
            wake.Wait(timeout ?? Timeout.InfiniteTimeSpan, _stop.Token);
            return true;
        }
        catch (OperationCanceledException)
        {
            return false;
        }
    }

    // Background threads: a failing texture is reported and keeps its original.
    private static void guard(Action work)
    {
        try
        {
            work();
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine($"Texture upscale failed: {exception.Message}");
        }
    }

    public void Dispose()
    {
        _stop.Cancel();
        _loader.Join(TimeSpan.FromSeconds(2));
        _upscaler.Join(TimeSpan.FromSeconds(2));
        _tool.Dispose();
    }
}
