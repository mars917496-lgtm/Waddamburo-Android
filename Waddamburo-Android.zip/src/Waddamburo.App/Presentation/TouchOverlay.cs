using Waddamburo.Platform.Sdl;
using Waddamburo.Platform.Sdl.Rendering;

namespace Waddamburo.App.Presentation;

/// <summary>
/// The touch controls, drawn over the scene: a row of keys at the top left (ESC, F11, TAB, L, Q) and the
/// drum, a red disc rising from the bottom edge. Translucent, so the scene shows through. What a finger can hit
/// is <see cref="SdlTouchControls"/>'s: the two stay the same shapes.
/// </summary>
internal sealed class TouchOverlay(OverlayPainter painter, Func<SdlKeyboardKey, bool> held, Func<bool> playing)
{
    private const float KeyTop = 17, KeyHeight = 76;
    private const float DiscLeft = 256, DiscTop = 386, DiscSize = 788;

    private static (byte R, byte G, byte B) Rgb(byte r, byte g, byte b) => (r, g, b);

    public IEnumerable<RenderQuad> Quads()
    {
        var quads = new List<RenderQuad>();
        var drumShown = playing();
        var discPressed = SdlInputBindings.Pads.Take(4).Any(held);
        if (drumShown)
            quads.Add(painter.Canvas(("touch-disc", discPressed), DiscLeft - 24, DiscTop - 24, DiscSize + 48, OverlayPainter.StageHeight - DiscTop + 24,
                canvas =>
                {
                    // A soft shadow down the right edge, then the outline and the red.
                    for (var i = 4; i >= 1; i--)
                        canvas.RoundedRect(24 + 6 * i - 2, 24 + 3 * i, DiscSize - 6 * i + 8, DiscSize, DiscSize / 2, Rgb(0, 0, 0), 0f);
                    canvas.RoundedRect(24, 24, DiscSize, DiscSize, DiscSize / 2,
                        discPressed ? Rgb(255, 40, 40) : Rgb(255, 0, 0), 3f, Rgb(110, 40, 40));
                }, alpha: discPressed ? .62f : .46f));

        foreach (var button in SdlTouchControls.Buttons)
        {
            var pressed = button.Key is { } key && held(key);
            var top = KeyTop + (pressed ? 2.5f : 0);
            quads.Add(painter.Canvas(("touch-key", button.Width, pressed), button.X - 20, KeyTop - 12, button.Width + 40, KeyHeight + 52,
                canvas =>
                {
                    for (var i = 5; i >= 1; i--)
                        canvas.RoundedRect(20 - i, 12 + i * 2.2f, button.Width + 2 * i, KeyHeight, 18 + i, Rgb(0, 0, 0), 0f);
                    canvas.RoundedRect(20, 12, button.Width, KeyHeight, 18, pressed ? Rgb(110, 110, 110) : Rgb(90, 90, 90),
                        3f, Rgb(140, 140, 140));
                }, alpha: pressed ? .7f : .58f));
            quads.Add(painter.Text(button.Label, button.X + button.Width / 2, top + KeyHeight / 2, button.Width - 12, 36,
                tint: Rgb(225, 225, 225), alpha: .9f));
        }
        return quads;
    }
}
