using Waddamburo.Game.Don;
using Waddamburo.Lumen.Rendering;
using Waddamburo.Platform.Sdl.Rendering;

namespace Waddamburo.App.Presentation;

/// <summary>The Lumen hosts' view of the 3D Don renderer: player slots, cameras, motions, costumes.</summary>
internal sealed class DonPresentationController(SdlDonRenderer renderer) : IDonPresentationController
{
    private readonly SdlDonRenderer _renderer = renderer;
    private readonly LumenNativeSurfaceKey[] _surfaces =
    [
        new("don:0"),
        new("don:1"),
        new("don:2"),
    ];

    /// <summary>Each player's displayed dan rank (from their look), which picks the dan costume's model.</summary>
    private readonly int[] _danRanks = new int[3];

    /// <summary>
    /// The player's drum. The right drum's player alone is drawn as Katsu-chan (the renderer's
    /// second slot) and never with the mirrored second-player camera.
    /// </summary>
    public int GameplaySide { get; set; }

    /// <summary>
    /// Scenes that draw the one player in their first Don slot (gameplay, results, revival): with a
    /// right-drum player, slot 0 is Katsu-chan's. Entry and Song Select address him as player 1.
    /// </summary>
    public bool MapPlayerZero { get; set; }

    private int slot(int playerIndex) => MapPlayerZero && playerIndex == 0 ? 1 : playerIndex;

    public void Reset(DonPresentationLayout layout)
    {
        // Entry and Song Select (Standard): the movies never turn the right-hand Don-chan, so the mirrored camera faces
        // them inward, a second player beside a first and a player alone on the right drum alike (the lone one faced
        // outward when the right drum was excepted here). Other layouts keep that exception: results stand both players
        // left of their panel (OpposedPlayers), and a lone right-drum player's other scenes were confirmed unmirrored.
        _renderer.Reset(mirrorPlayerTwoCamera: layout == DonPresentationLayout.Standard
                || layout != DonPresentationLayout.OpposedPlayers && GameplaySide != 1,
            layout: cameraLayout(layout));
    }

    public void SetCameraLayout(DonPresentationLayout layout) => _renderer.SetCameraLayout(cameraLayout(layout));

    // Gameplay overlays: the shared kusudama shows both Dons facing the centre, so Katsu-chan takes
    // the reflected camera; each lane's balloon shows its Don unreflected (user-confirmed).
    public void SetCameraLayout(int playerIndex, DonPresentationLayout layout)
    {
        _renderer.MirrorPlayerTwoCamera = layout == DonPresentationLayout.Kusudama && GameplaySide != 1;
        _renderer.SetCameraLayout(slot(playerIndex), cameraLayout(layout));
    }

    public void SetModelRotation(int playerIndex, float yaw, float pitch, float roll) =>
        _renderer.SetModelRotation(slot(playerIndex), yaw, pitch, roll);

    private static DonCameraLayout cameraLayout(DonPresentationLayout layout) => layout switch
    {
        DonPresentationLayout.Gameplay => DonCameraLayout.Gameplay,
        DonPresentationLayout.Retry => DonCameraLayout.Retry,
        DonPresentationLayout.RetrySuccess => DonCameraLayout.RetrySuccess,
        DonPresentationLayout.Balloon => DonCameraLayout.Balloon,
        _ => DonCameraLayout.Standard,
    };

    public LumenNativeSurfaceKey GetSurface(int playerIndex) => _surfaces[slot(playerIndex)];

    public void SetMotion(DonMotionRequest request) =>
        _renderer.SetMotion(slot(request.PlayerIndex), request.OneShot, request.Loop);

    public void SetIdle(int playerIndex, string loop) => _renderer.SetIdle(slot(playerIndex), loop);

    public void SetCostume(int playerIndex, DonCostume costume)
    {
        try
        {
            // The dan costume has one model per rank (cos_036001..025); without a rank, the plain cos_036000.
            var variant = costume.Whole == DonCostume.Dan && playerIndex < _danRanks.Length ? _danRanks[playerIndex] : 0;
            _renderer.SetCostume(playerIndex, costume.Whole, costume.Head, costume.Body, costume.Paint, variant);
        }
        catch (FileNotFoundException exception)
        {
            // A costume the installed data lacks keeps the current look.
            Console.Error.WriteLine($"Don costume {costume}: {exception.Message}");
        }
    }

    public void SetAccessory(int playerIndex, int puchi)
    {
        try
        {
            _renderer.SetAccessory(playerIndex, puchi);
        }
        catch (FileNotFoundException exception)
        {
            Console.Error.WriteLine($"Don puchi {puchi}: {exception.Message}");
        }
    }

    public void SetLook(int playerIndex, DonLook? look)
    {
        if (playerIndex < _danRanks.Length)
            _danRanks[playerIndex] = look?.DanRank is >= 1 and <= 25 and var rank ? rank : 0;
        SetCostume(playerIndex, look?.ToCostume() ?? DonCostume.Default);
        SetAccessory(playerIndex, look?.Puchi ?? 0);
        _renderer.SetColors(playerIndex, look?.Colors);
    }

    public void SetDialogDon(bool visible)
    {
        _renderer.DialogVisible = visible;
        if (visible)
            _renderer.SetMotion(2, null, "don_entry_loop"); // traced p2 don_entry_loop
    }

    public RenderTextureId? Resolve(LumenNativeSurfaceKey surface)
    {
        for (var index = 0; index < _surfaces.Length; index++)
            if (surface == _surfaces[index])
                return _renderer.GetTexture(index);
        return null;
    }
}
