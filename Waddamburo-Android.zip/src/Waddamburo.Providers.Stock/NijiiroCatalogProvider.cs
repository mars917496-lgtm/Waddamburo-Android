using System.Collections.Immutable;
using System.Buffers.Binary;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;
using Waddamburo.Catalog;

namespace Waddamburo.Providers.Stock;

/// <summary>
/// A user's Nijiiro installation, read in place: <c>datatable/musicinfo</c> and <c>wordlist</c> (JSON
/// <c>items</c>), charts <c>fumen/&lt;id&gt;/&lt;id&gt;_&lt;e|n|h|m|x&gt;[_1|_2].bin</c> in the arcade fumen
/// layout (either byte order), music <c>sound/song_&lt;id&gt;.nus3bank</c>. Files are plain, gzip, or
/// AES-256-CBC (16-byte IV first, PKCS#7, then maybe gzip) with the player's keys (<see cref="NijiiroKeys"/>, from
/// config.cfg): one for the data tables, one for the charts. The engine carries no key and reads none from the install.
/// </summary>
public sealed partial class NijiiroCatalogProvider : ISongCatalogProvider, ICatalogAssetResolver, IPlayableChartProvider
{
    private const int MaximumFileBytes = 16 * 1024 * 1024;
    private const int MaximumMeasures = 16_384;
    private const int MaximumNotes = 1_000_000;
    private const string Courses = "enhmx";
    private static readonly string[] StarFields = ["starEasy", "starNormal", "starHard", "starMania", "starUra"];
    private static readonly string[] BranchFields = ["branchEasy", "branchNormal", "branchHard", "branchMania", "branchUra"];
    // genreNo 0-7, named as the Song Select categories are (their art and colours).
    private static readonly string[] Genres = ["J-POP", "Anime", "Kids", "Vocaloid", "Game Music", "Namco Original", "Variety", "Classical"];

    private readonly string _root;
    private readonly NijiiroKeys _keys;
    private Dictionary<string, int[]> _stars = [];

    /// <param name="folder">The installation, its <c>Data/x64</c>, or its <c>fumen</c> folder.</param>
    /// <param name="id">The provider id (default "nijiiro").</param>
    /// <param name="keys">The keys the installation's encrypted files open with (the player's, from config.cfg).</param>
    public NijiiroCatalogProvider(string folder, CatalogProviderId? id = null, NijiiroKeys? keys = null)
    {
        _keys = keys ?? NijiiroKeys.None;
        ArgumentException.ThrowIfNullOrWhiteSpace(folder);
        var root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(folder));
        if (Path.GetFileName(root) == "fumen")
            root = Path.GetDirectoryName(root)!;
        if (Directory.Exists(Path.Combine(root, "Data", "x64")))
            root = Path.Combine(root, "Data", "x64");
        else if (Directory.Exists(Path.Combine(root, "x64")))
            root = Path.Combine(root, "x64");
        _root = root;
        Id = id ?? new CatalogProviderId("nijiiro");
    }

    public CatalogProviderId Id { get; }

    /// <summary>The data folder read (the installation's <c>Data/x64</c>).</summary>
    public string Root => _root;

    public SongSourceKind Source => SongSourceKind.Nijiiro;

    /// <summary>
    /// After <see cref="Problem"/>: the files are encrypted and the keys given (config.cfg's nijiiro_datatable_key /
    /// nijiiro_fumen_key) are missing or don't open them.
    /// </summary>
    public bool KeysMissing { get; private set; }

    /// <summary>True when the folder resolves to a Nijiiro data folder.</summary>
    public bool Exists => Directory.Exists(Path.Combine(_root, "fumen")) && Directory.Exists(Path.Combine(_root, "sound"));

    /// <summary>
    /// Why the installation cannot be played (null: it can): no data there, or its song table does not
    /// decrypt (config.cfg's keys are missing or wrong, so no chart or song would either).
    /// </summary>
    public string? Problem
    {
        get
        {
            if (!Exists)
                return "No Nijiiro data there.";
            try
            {
                _ = table("musicinfo");
                return null;
            }
            catch (Exception exception) when (exception is InvalidDataException or IOException or JsonException
                or KeyNotFoundException or InvalidOperationException or UnauthorizedAccessException)
            {
                return exception.Message;
            }
        }
    }

    /// <summary>
    /// The highest song number in the installation's song table (0 when it can't be read): a later release adds songs
    /// with higher numbers, so between two installations the higher one is the newer.
    /// </summary>
    public int NewestSong
    {
        get
        {
            try
            {
                return table("musicinfo").Select(static entry => entry.TryGetProperty("uniqueId", out var number)
                    && number.TryGetInt32(out var value) ? value : 0).DefaultIfEmpty().Max();
            }
            catch (Exception exception) when (exception is InvalidDataException or IOException or JsonException
                or KeyNotFoundException or InvalidOperationException or UnauthorizedAccessException)
            {
                return 0;
            }
        }
    }

    public ValueTask<SongCatalogContribution> ScanAsync(IProgress<CatalogScanProgress>? progress, CancellationToken cancellationToken)
    {
        progress?.Report(new CatalogScanProgress(Id, "discover", 0, null));
        var diagnostics = new List<CatalogDiagnostic>();
        var music = table("musicinfo");
        var titles = new Dictionary<string, (string Japanese, string English)>(StringComparer.Ordinal);
        foreach (var entry in table("wordlist"))
        {
            var japanese = text(entry, "japaneseText");
            var english = text(entry, "englishUsText");
            // Megamix repeats keys, later ones blank or holding a subtitle: the first usable one wins.
            if ((japanese ?? english) is { } any && text(entry, "key") is { } key)
                titles.TryAdd(key, (japanese ?? any, english ?? any));
        }

        var themes = ensoThemes(diagnostics);
        var songs = new List<SongDescriptor>();
        var categories = new SortedDictionary<int, List<SongKey>>();
        var stars = new Dictionary<string, int[]>(StringComparer.Ordinal);
        var seen = new HashSet<string>(StringComparer.Ordinal);
        for (var index = 0; index < music.Count; index++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            progress?.Report(new CatalogScanProgress(Id, "inspect", index, music.Count));
            var entry = music[index];
            if (text(entry, "id") is not { } id || !SongId().IsMatch(id) || !seen.Add(id))
                continue;
            var audio = audioPath(id);
            if (!File.Exists(audio))
            {
                diagnostics.Add(warning("NIJIIRO_AUDIO_MISSING", $"Song '{id}' has no song_{id}.nus3bank."));
                continue;
            }
            var key = new SongKey(Source, id);
            var levels = new int[Courses.Length];
            var charts = new List<SongChartDescriptor>();
            for (var course = 0; course < Courses.Length; course++)
            {
                var letter = Courses[course];
                if (!File.Exists(chartPath(id, letter, "")))
                    continue;
                levels[course] = entry.TryGetProperty(StarFields[course], out var star) && star.TryGetInt32(out var value)
                    && value is > 0 and <= 10 ? value : 0;
                // A missing player file falls back to the solo chart (as the game does).
                charts.Add(new SongChartDescriptor(
                    new ChartKey(key, ((TaikoCourse)course).ToString().ToLowerInvariant()),
                    ((TaikoCourse)course).ToString(),
                    new CatalogAssetKey(Id, $"chart:{id}:{letter}"),
                    (TaikoCourse)course,
                    levels[course] > 0 ? levels[course] : null,
                    [new CatalogAssetKey(Id, $"chart:{id}:{letter}:1"), new CatalogAssetKey(Id, $"chart:{id}:{letter}:2")])
                {
                    HasBranches = entry.TryGetProperty(BranchFields[course], out var branch) && branch.ValueKind == JsonValueKind.True,
                });
            }
            if (charts.Count == 0)
                continue;
            stars[id] = levels;
            var title = titles.GetValueOrDefault("song_" + id);
            var subtitle = titles.GetValueOrDefault("song_sub_" + id);
            songs.Add(new SongDescriptor(
                key,
                new SongTitle(title.Japanese ?? id, title.Japanese, title.English),
                null,
                charts,
                new CatalogAssetKey(Id, $"audio:{id}"),
                previewStart(audio),
                subtitle.Japanese)
            {
                EnglishSubtitle = subtitle.English,
                ScenePresets = themes.GetValueOrDefault(id, []),
            });
            var genre = entry.TryGetProperty("genreNo", out var number) && number.TryGetInt32(out var genreNo)
                && genreNo >= 0 && genreNo < Genres.Length ? genreNo : Genres.Length;
            if (!categories.TryGetValue(genre, out var list))
                categories[genre] = list = [];
            list.Add(key);
        }
        _stars = stars;
        progress?.Report(new CatalogScanProgress(Id, "complete", music.Count, music.Count));
        return ValueTask.FromResult(new SongCatalogContribution(
            Id,
            Source,
            songs,
            categories.Select((pair, order) => new SongCategoryDescriptor(
                new CategoryKey(Source, pair.Key.ToString(System.Globalization.CultureInfo.InvariantCulture)),
                pair.Key < Genres.Length ? Genres[pair.Key] : "Other",
                order,
                pair.Value)),
            diagnostics));
    }

    public ValueTask<Stream> OpenReadAsync(CatalogAssetKey asset, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(asset);
        if (asset.Provider != Id || asset.StableId.Split(':') is not ["audio", var id] || !SongId().IsMatch(id))
            throw new ArgumentException("The asset is not Nijiiro music of this provider.", nameof(asset));
        // A FileStream: the decoder hands its path to vgmstream-cli for G.719 banks.
        Stream stream = new FileStream(audioPath(id), FileMode.Open, FileAccess.Read, FileShare.Read, 64 * 1024,
            FileOptions.Asynchronous | FileOptions.SequentialScan);
        return ValueTask.FromResult(stream);
    }

    public async ValueTask<PlayableChart> LoadChartAsync(ChartKey chart, CatalogAssetKey asset, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(chart);
        ArgumentNullException.ThrowIfNull(asset);
        if (asset.Provider != Id || asset.StableId.Split(':') is not ["chart", var id, [var letter], .. var player]
            || !SongId().IsMatch(id) || !Courses.Contains(letter, StringComparison.Ordinal)
            || player is not ([] or ["1" or "2"]))
            throw new ArgumentException("The asset is not a Nijiiro chart of this provider.", nameof(asset));
        var path = chartPath(id, letter, player is [var side] ? "_" + side : "");
        if (!File.Exists(path))
            path = chartPath(id, letter, "");
        if (new FileInfo(path).Length > MaximumFileBytes)
            throw new InvalidDataException("The selected fumen exceeds the chart-size limit.");
        var bytes = unpack(await File.ReadAllBytesAsync(path, cancellationToken).ConfigureAwait(false), table: false);
        var course = Courses.IndexOf(letter, StringComparison.Ordinal);
        return FumenChartReader.Read(bytes, chart, MaximumMeasures, MaximumNotes) with
        {
            Level = _stars.TryGetValue(id, out var levels) && levels[course] > 0 ? levels[course] : null,
        };
    }

    private string chartPath(string id, char course, string player) =>
        Path.Combine(_root, "fumen", id, $"{id}_{course}{player}.bin");

    private string audioPath(string id) => Path.Combine(_root, "sound", $"song_{id}.nus3bank");

    // datatable/<name>.json, or the packed .bin; its "items" array.
    // The songs' own gameplay themes: music_attribute's ensoPartsID1 names a music_ensoparts entry, whose
    // parts sit under lumen/<NNN_theme>/ (001_miku, 011_imas_cg, ...). As presets, the theme then its
    // series (imas_cg, imas), Green's archive names where they differ; empty without the tables.
    private Dictionary<string, ImmutableArray<string>> ensoThemes(List<CatalogDiagnostic> diagnostics)
    {
        var themes = new Dictionary<string, ImmutableArray<string>>(StringComparer.Ordinal);
        try
        {
            var parts = new Dictionary<int, string>();
            foreach (var entry in table("music_ensoparts"))
                if (entry.TryGetProperty("uniqueId", out var number) && number.TryGetInt32(out var partsId)
                    && text(entry, "dancer")?.Split('/') is [_, var folder, ..] && folder.IndexOf('_') is var cut and > 0)
                    parts[partsId] = folder[(cut + 1)..];
            foreach (var entry in table("music_attribute"))
                if (text(entry, "id") is { } id && entry.TryGetProperty("ensoPartsID1", out var number)
                    && number.TryGetInt32(out var partsId) && parts.TryGetValue(partsId, out var theme))
                    themes[id] = [GreenThemes.GetValueOrDefault(theme, theme), theme.Split('_')[0]];
        }
        catch (Exception exception) when (exception is IOException or InvalidDataException or JsonException
            or KeyNotFoundException or UnauthorizedAccessException)
        {
            diagnostics.Add(warning("NIJIIRO_THEMES_UNREADABLE", $"The songs' gameplay themes could not be read: {exception.Message}"));
        }
        return themes;
    }

    // Nijiiro theme folders Green names otherwise (the rest match ignoring case and punctuation).
    private static readonly Dictionary<string, string> GreenThemes = new(StringComparer.Ordinal)
    {
        ["yokai_mb"] = "yokai_matsuri",
        ["yokai_ht"] = "yokai_hatsukoi",
        ["yokai_yt"] = "yokai_yougota",
    };

    private List<JsonElement> table(string name)
    {
        var path = Path.Combine(_root, "datatable", name + ".json");
        if (!File.Exists(path))
            path = Path.ChangeExtension(path, ".bin");
        using var document = JsonDocument.Parse(unpack(File.ReadAllBytes(path), table: true));
        return [.. document.RootElement.GetProperty("items").EnumerateArray().Select(static item => item.Clone())];
    }

    private byte[] unpack(byte[] data, bool table)
    {
        if (isGzip(data))
            return inflate(data);
        if (plausible(data, table))
            return data;
        if (data.Length < 32 || data.Length % 16 != 0)
            throw new InvalidDataException("The Nijiiro file is neither plain, gzip nor AES-encrypted.");
        if ((table ? _keys.Datatable : _keys.Fumen) is { } key)
        {
            using var aes = Aes.Create();
            aes.Key = key;
            try
            {
                var plain = aes.DecryptCbc(data.AsSpan(16), data.AsSpan(0, 16), PaddingMode.PKCS7);
                if (isGzip(plain))
                    return inflate(plain);
                if (plausible(plain, table))
                    return plain;
            }
            catch (CryptographicException)
            {
                // the wrong key: the padding does not check out
            }
        }
        KeysMissing = true;
        throw new InvalidDataException(table
            ? "Nijiiro's data tables are encrypted: put their key in config.cfg's nijiiro_datatable_key (64 hex digits)."
            : "Nijiiro's charts are encrypted: put their key in config.cfg's nijiiro_fumen_key (64 hex digits).");
    }

    private static bool isGzip(byte[] data) => data.Length > 2 && data[0] == 0x1f && data[1] == 0x8b;

    private static byte[] inflate(byte[] data)
    {
        using var gzip = new GZipStream(new MemoryStream(data), CompressionMode.Decompress);
        using var output = new MemoryStream();
        var buffer = new byte[81920];
        int read;
        while ((read = gzip.Read(buffer)) > 0)
        {
            output.Write(buffer, 0, read);
            if (output.Length > MaximumFileBytes)
                throw new InvalidDataException("A decompressed Nijiiro file exceeds 16 MiB.");
        }
        return output.ToArray();
    }

    // A table is JSON (an object); a fumen has its 12345678 marker at 508 or a sane measure count at 512.
    private static bool plausible(byte[] data, bool table)
    {
        if (table)
        {
            var text = data.AsSpan(data.AsSpan().StartsWith("\xef\xbb\xbf"u8) ? 3 : 0);
            var first = text.IndexOfAnyExcept(" \r\n\t"u8);
            return first >= 0 && text[first] == (byte)'{';
        }
        if (data.Length < 520)
            return false;
        var span = data.AsSpan();
        if (BinaryPrimitives.ReadUInt32LittleEndian(span[508..]) == 12345678 || BinaryPrimitives.ReadUInt32BigEndian(span[508..]) == 12345678)
            return true;
        return BinaryPrimitives.ReadUInt32LittleEndian(span[512..]) is > 0 and <= MaximumMeasures
            || BinaryPrimitives.ReadUInt32BigEndian(span[512..]) is > 0 and <= MaximumMeasures;
    }

    // The 39.06 single-song bank template keeps its preview cue (ms) at 0x6C4; other layouts start at 0.
    private static TimeSpan? previewStart(string bank)
    {
        try
        {
            var header = new byte[0x750];
            using (var stream = File.OpenRead(bank))
                if (stream.ReadAtLeast(header, header.Length, throwOnEndOfStream: false) < header.Length)
                    return null;
            var span = header.AsSpan();
            if (!span.StartsWith("NUS3"u8) || !span[0x748..].StartsWith("PACK"u8) || !span[0x5EC..].StartsWith("TONE"u8)
                || BinaryPrimitives.ReadUInt32LittleEndian(span[0x5F0..]) != 0x140)
                return null;
            var cue = BinaryPrimitives.ReadUInt32LittleEndian(span[0x6C4..]);
            return cue < 3_600_000 ? TimeSpan.FromMilliseconds(cue) : null;
        }
        catch (IOException)
        {
            return null;
        }
    }

    private static string? text(JsonElement entry, string name) =>
        entry.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            && value.GetString() is { } text && !string.IsNullOrWhiteSpace(text) ? text : null;

    private CatalogDiagnostic warning(string code, string message) =>
        new(CatalogDiagnosticSeverity.Warning, code, message, Id);

    [GeneratedRegex("^[A-Za-z0-9_-]{1,64}$")]
    private static partial Regex SongId();
}

/// <summary>
/// The AES keys Nijiiro's encrypted files open with: one for the data tables, one for the charts (fumen). The player
/// puts them in config.cfg (nijiiro_datatable_key, nijiiro_fumen_key); the engine carries none.
/// </summary>
public sealed record NijiiroKeys(byte[]? Datatable, byte[]? Fumen)
{
    public static NijiiroKeys None { get; } = new(null, null);

    /// <summary>From config.cfg's hex texts; an empty or malformed one is no key.</summary>
    public static NijiiroKeys Parse(string? datatable, string? fumen) => new(hex(datatable), hex(fumen));

    private static byte[]? hex(string? text)
    {
        text = text?.Trim();
        if (string.IsNullOrEmpty(text) || text.Length != 64)
            return null;
        try
        {
            return Convert.FromHexString(text);
        }
        catch (FormatException)
        {
            return null;
        }
    }
}
