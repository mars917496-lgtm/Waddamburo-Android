package org.waddamburo;

import android.content.Context;
import android.system.Os;
import android.util.Log;
import java.io.File;
import org.libsdl.app.SDLActivity;

/**
 * SDL's activity for the game. SDL starts libmain.so's SDL_main on its own thread; that calls runManaged(), which
 * hands over to the game's C# Main (ManagedEntry: the Java wrapper .NET generates from the C# class of the same name).
 */
public class WaddamburoActivity extends SDLActivity {
    @Override
    protected String[] getLibraries() {
        // libmain.so (native/android/main.c) last: SDL runs the last library's SDL_main.
        return new String[] { "SDL3", "main" };
    }

    /** Called from SDL_main on SDL's main thread; returns when the game has quit. */
    public static void runManaged() {
        Context context = (Context) SDLActivity.getContext();
        File base = context.getExternalFilesDir(null);
        if (base == null)
            base = context.getFilesDir();
        // The game's folder (data/, custom_songs/, waddamburo/): <app's files>/USRDIR, where the player puts the data.
        File usrdir = new File(base, "USRDIR");
        usrdir.mkdirs();
        try {
            // The arguments (newline separated) go to the managed side through the environment.
            Os.setenv("WADDAMBURO_ARGS", "--game-data=" + usrdir.getAbsolutePath(), true);
        } catch (Exception exception) {
            Log.e("Waddamburo", "Could not pass the arguments", exception);
        }
        new ManagedEntry().run();
    }
}
