# Waddamburo for Android (skeleton)

How it starts: SDL's Java activity (`java/org/libsdl/app`, with `org.waddamburo.WaddamburoActivity`) -> `libmain.so`'s
`SDL_main` (`native/android/main.c`) -> `WaddamburoActivity.runManaged()` -> `ManagedEntry.Run` (C#, a Java Runnable) -> Waddamburo.App's `Main`
with `--game-data=<app files>/USRDIR`.

## Build

1. `dotnet workload install android`, and the Android SDK + NDK (r27 or newer). On Windows, build the native libraries in WSL
   (FFmpeg's configure needs a POSIX shell); the .NET app can be built on Windows afterwards.
2. Native libraries for `armeabi-v7a`, `arm64-v8a`, `x86` and `x86_64`, in Linux/WSL, with `ANDROID_NDK` and
   `SDL3_SOURCE_DIR` set:
   ```
   eng/build-android-native.sh
   ```
   By default it builds all four ABIs and places each ABI's libraries in its own `jniLibs/<abi>/` folder. Set
   `ANDROID_ABIS="arm64-v8a"` (or any space-separated subset) to build selected ABIs. For each ABI it builds SDL/libmain and
   the game's libraries (FFmpeg, opus, vgmstream, FreeType, bgfx and Waddamburo wrappers).
3. Restore and build/publish `src/Waddamburo.Android` in Release. The project declares `android-arm`, `android-arm64`,
   `android-x86` and `android-x64`
   runtime identifiers; the APK includes only ABIs for which matching native libraries exist under `jniLibs/<abi>/`.
4. Put the game's data in `Android/data/org.waddamburo.game/files/USRDIR` on the device.

The shaders (`eng/build-shaders.sh`) already include the ESSL 300 (`android`) and Vulkan SPIR-V variants.

The APK has not been runtime-tested on a device/emulator. Custom native libraries must be built separately for each declared ABI.
