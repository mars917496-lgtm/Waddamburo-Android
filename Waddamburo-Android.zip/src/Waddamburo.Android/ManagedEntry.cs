using System.Reflection;
using Android.Runtime;

namespace Waddamburo.Android;

/// <summary>
/// Where Android hands over to the game: <c>WaddamburoActivity.runManaged()</c> (on SDL's main thread, from SDL_main)
/// runs this as a <see cref="Java.Lang.IRunnable"/>, which starts Waddamburo.App's own entry point with the arguments
/// from WADDAMBURO_ARGS (newline separated). A plain Runnable: no export attributes are needed.
/// </summary>
[Register("org/waddamburo/ManagedEntry")]
public sealed class ManagedEntry : Java.Lang.Object, Java.Lang.IRunnable
{
    public ManagedEntry()
    {
    }

    public ManagedEntry(IntPtr handle, JniHandleOwnership transfer) : base(handle, transfer)
    {
    }

    public void Run()
    {
        try
        {
            var args = (Environment.GetEnvironmentVariable("WADDAMBURO_ARGS") ?? "")
                .Split('\n', StringSplitOptions.RemoveEmptyEntries);
            // Relative paths and the game's defaults start from its own folder.
            var gameData = args.FirstOrDefault(static argument => argument.StartsWith("--game-data=", StringComparison.Ordinal));
            if (gameData is not null)
                Directory.SetCurrentDirectory(gameData["--game-data=".Length..]);
            var entry = Assembly.Load("Waddamburo.App").EntryPoint
                ?? throw new InvalidOperationException("Waddamburo.App has no entry point.");
            var result = entry.Invoke(null, entry.GetParameters().Length == 0 ? null : [args]);
            global::Android.Util.Log.Info("Waddamburo", $"The game exited with {result ?? 0}.");
        }
        catch (Exception exception)
        {
            global::Android.Util.Log.Error("Waddamburo", exception.ToString());
        }
    }
}
