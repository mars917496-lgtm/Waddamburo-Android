using System.Collections.Immutable;

namespace Waddamburo.Catalog;

public enum TaikoCourse
{
    Easy,
    Normal,
    Hard,
    Oni,
    Ura,
}

public sealed record SongTitle
{
    public SongTitle(string primary, string? japanese = null, string? english = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(primary);
        Primary = primary;
        Japanese = normalize(japanese);
        English = normalize(english);
    }

    public string Primary { get; }

    public string? Japanese { get; }

    public string? English { get; }

    private static string? normalize(string? value) => string.IsNullOrWhiteSpace(value) ? null : value;
}

public sealed record SongChartDescriptor
{
    public SongChartDescriptor(
        ChartKey key,
        string difficultyName,
        CatalogAssetKey chartAsset,
        TaikoCourse? course = null,
        int? level = null,
        IEnumerable<CatalogAssetKey>? duetChartAssets = null)
    {
        ArgumentNullException.ThrowIfNull(key);
        ArgumentException.ThrowIfNullOrWhiteSpace(difficultyName);
        ArgumentNullException.ThrowIfNull(chartAsset);
        if (level < 0)
            throw new ArgumentOutOfRangeException(nameof(level));
        Key = key;
        DifficultyName = difficultyName;
        ChartAsset = chartAsset;
        Course = course;
        Level = level;
        DuetChartAssets = duetChartAssets?.ToImmutableArray() ?? [];
        if (DuetChartAssets.Length is not (0 or 2) || DuetChartAssets.Any(static asset => asset is null))
            throw new ArgumentException("Duet charts come as one per player, left then right.", nameof(duetChartAssets));
    }

    public ChartKey Key { get; }

    public string DifficultyName { get; }

    public CatalogAssetKey ChartAsset { get; }

    public TaikoCourse? Course { get; }

    public int? Level { get; }

    /// <summary>
    /// The course's two-player charts (left drum, right drum), empty when the course has none. The
    /// game's own songs author them apart from the solo chart (different parts, hand notes).
    /// </summary>
    public ImmutableArray<CatalogAssetKey> DuetChartAssets { get; }

    /// <summary>The chart's id on its online source (an osu.ppy.sh beatmap id), when known.</summary>
    public int? OnlineId { get; init; }

    /// <summary>The chart has 譜面分岐 (song select marks the course 分岐).</summary>
    public bool HasBranches { get; init; }
}

public sealed record SongDescriptor
{
    public SongDescriptor(
        SongKey key,
        SongTitle title,
        string? artist,
        IEnumerable<SongChartDescriptor> charts,
        CatalogAssetKey? audioAsset = null,
        TimeSpan? previewStart = null,
        string? subtitle = null)
    {
        ArgumentNullException.ThrowIfNull(key);
        ArgumentNullException.ThrowIfNull(title);
        ArgumentNullException.ThrowIfNull(charts);
        var materialized = charts.ToImmutableArray();
        if (materialized.IsEmpty)
            throw new ArgumentException("A song must expose at least one chart.", nameof(charts));
        if (materialized.Any(chart => chart is null || chart.Key.Song != key))
            throw new ArgumentException("Every chart key must belong to its song.", nameof(charts));
        if (materialized.Select(static chart => chart.Key).Distinct().Count() != materialized.Length)
            throw new ArgumentException("Chart keys must be unique within a song.", nameof(charts));
        if (previewStart < TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(previewStart));

        Key = key;
        Title = title;
        Artist = string.IsNullOrWhiteSpace(artist) ? null : artist;
        Charts = materialized;
        AudioAsset = audioAsset;
        PreviewStart = previewStart;
        Subtitle = string.IsNullOrWhiteSpace(subtitle) ? null : subtitle;
    }

    public SongKey Key { get; }

    public SongTitle Title { get; }

    public string? Artist { get; }

    public ImmutableArray<SongChartDescriptor> Charts { get; }

    public CatalogAssetKey? AudioAsset { get; }

    public TimeSpan? PreviewStart { get; }

    public string? Subtitle { get; }

    /// <summary>The subtitle in English when the song also has a Japanese one (<see cref="Subtitle"/>).</summary>
    public string? EnglishSubtitle { get; init; }

    /// <summary>
    /// The song's Waiwai (party mode) section layout, when the song can be played in Waiwai; the
    /// game's own songs author it (fumen/&lt;id&gt;/composition.xml).
    /// </summary>
    public CatalogAssetKey? WaiwaiComposition { get; init; }

    /// <summary>
    /// Gameplay backgrounds the chart asks for by name, first preferred (OpenTaiko's TJA
    /// <c>SCENEPRESET:</c>, e.g. IMAS, A3); they override the one picked by title or genre.
    /// </summary>
    public ImmutableArray<string> ScenePresets { get; init; } = [];

    /// <summary>In the game's own attract demo rotation (Green's musicinfo <c>demoplay</c>).</summary>
    public bool DemoPlay { get; init; }

    /// <summary>The chart author (osu! mapper), when the source names one; for browsing.</summary>
    public string? Creator { get; init; }

    /// <summary>The song's id on its online source (an osu.ppy.sh beatmap set id), when known.</summary>
    public int? OnlineSetId { get; init; }

    /// <summary>When the song joined the player's library, when the source records it; for browsing.</summary>
    public DateTimeOffset? DateAdded { get; init; }

    /// <summary>The song's main tempo, when the source states it; for browsing.</summary>
    public double? Bpm { get; init; }

    /// <summary>The song's playable length, when the source states it; for browsing.</summary>
    public TimeSpan? Length { get; init; }
}

public sealed record SongCategoryDescriptor
{
    public SongCategoryDescriptor(
        CategoryKey key,
        string name,
        int sortOrder,
        IEnumerable<SongKey> songs)
    {
        ArgumentNullException.ThrowIfNull(key);
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentNullException.ThrowIfNull(songs);
        var materialized = songs.ToImmutableArray();
        if (materialized.Distinct().Count() != materialized.Length)
            throw new ArgumentException("A category cannot contain the same song twice.", nameof(songs));
        Key = key;
        Name = name;
        SortOrder = sortOrder;
        Songs = materialized;
    }

    public CategoryKey Key { get; }

    public string Name { get; }

    public int SortOrder { get; }

    public ImmutableArray<SongKey> Songs { get; }

    /// <summary>The genre the folder declares (a TJA box.def #GENRE), when it does.</summary>
    public string? Genre { get; init; }

    /// <summary>The folder's colour as 0xRRGGBB (box.def #BACKCOLOR), when it declares one.</summary>
    public uint? Colour { get; init; }

    /// <summary>The folder name's outline colour as 0xRRGGBB (box.def #FORECOLOR), when it declares one.</summary>
    public uint? OutlineColour { get; init; }

    /// <summary>The folder's description lines (box.def #BOXEXPLANATION1-3).</summary>
    public ImmutableArray<string> Description { get; init; } = [];

    /// <summary>Event-folder style pictures (box.def #SPINEIMAGE/#HEADERIMAGE/#BOXIMAGE): full paths, when given.</summary>
    public string? SpineImage { get; init; }

    /// <inheritdoc cref="SpineImage"/>
    public string? HeaderImage { get; init; }

    /// <inheritdoc cref="SpineImage"/>
    public string? BoxImage { get; init; }
}

public enum CatalogDiagnosticSeverity
{
    Information,
    Warning,
    Error,
}

public sealed record CatalogDiagnostic(
    CatalogDiagnosticSeverity Severity,
    string Code,
    string Message,
    CatalogProviderId Provider)
{
    public CatalogDiagnosticSeverity Severity { get; } = Severity;

    public string Code { get; } = string.IsNullOrWhiteSpace(Code)
        ? throw new ArgumentException("Diagnostic code is required.", nameof(Code))
        : Code;

    public string Message { get; } = string.IsNullOrWhiteSpace(Message)
        ? throw new ArgumentException("Diagnostic message is required.", nameof(Message))
        : Message;

    public CatalogProviderId Provider { get; } = Provider ?? throw new ArgumentNullException(nameof(Provider));
}
