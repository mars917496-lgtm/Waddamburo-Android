#!/usr/bin/env bash
# Builds the game's native libraries for each selected ABI and copies them into the app's jniLibs:
# libmain.so (SDL_main, native/android) and the game's own (bgfx, waddamburo_media/text/texture).
# libSDL3.so and its Java classes are supplied together by the ppy.SDL3-CS AAR.
# Linux or WSL. Needs: ANDROID_NDK (r27+), SDL3_SOURCE_DIR (the SDL tag the app's Java files come from: release-3.4.x),
# cmake, ninja, make, pkg-config, curl. Override ANDROID_ABIS with a space-separated ABI list if desired.
set -euo pipefail
: "${ANDROID_NDK:?set ANDROID_NDK to the NDK folder}"
: "${SDL3_SOURCE_DIR:?set SDL3_SOURCE_DIR to a checkout of SDL (release-3.4.x)}"

root="$(cd "$(dirname "$0")/.." && pwd)"
native="$root/native"
ANDROID_ABIS="${ANDROID_ABIS:-armeabi-v7a arm64-v8a x86 x86_64}"

for abi in $ANDROID_ABIS; do
  case "$abi" in
    armeabi-v7a) preset=android-arm-package; native_arch=android-arm ;;
    arm64-v8a) preset=android-arm64-package; native_arch=android-arm64 ;;
    x86) preset=android-x86-package; native_arch=android-x86 ;;
    x86_64) preset=android-x64-package; native_arch=android-x64 ;;
    *) echo "Unsupported Android ABI: $abi (supported: armeabi-v7a arm64-v8a x86 x86_64)" >&2; exit 2 ;;
  esac

  jni="$root/src/Waddamburo.Android/jniLibs/$abi"
  sdl_build="$root/out/build/android/$abi/sdl"
  mkdir -p "$jni"

  # 1. SDL and SDL_main
  cmake -S "$root/native/android" -B "$sdl_build" -G Ninja -DCMAKE_BUILD_TYPE=Release \
    -DSDL3_SOURCE_DIR="$SDL3_SOURCE_DIR" -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-24 \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK/build/cmake/android.toolchain.cmake"
  cmake --build "$sdl_build"
  cp "$sdl_build/libmain.so" "$jni/"

  # 2. The game's libraries (FFmpeg, opus, vgmstream, FreeType, bgfx and ours)
  cmake -S "$native" --preset "$preset"
  cmake --build "$root/out/build/native/$native_arch/$preset"
  cp "$root"/out/build/native/"$native_arch"/"$preset"/stage/Release/lib/*.so "$jni/"

  echo "Built Android ABI: $abi"
  ls -l "$jni"
done
