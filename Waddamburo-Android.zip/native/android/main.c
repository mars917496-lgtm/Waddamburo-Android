// SDL_main for Android: SDL's activity runs this on its main thread (libmain.so, the last of the activity's libraries).
// It calls the activity's static runManaged(), which starts the game's C# Main and returns once the game has quit.
#include <jni.h>
#include <SDL3/SDL.h>

__attribute__((visibility("default"))) int SDL_main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;
    JNIEnv *env = (JNIEnv *)SDL_GetAndroidJNIEnv();
    jobject activity = (jobject)SDL_GetAndroidActivity();
    if (env == NULL || activity == NULL)
        return 1;
    jclass activityClass = (*env)->GetObjectClass(env, activity);
    jmethodID run = (*env)->GetStaticMethodID(env, activityClass, "runManaged", "()V");
    if (run != NULL)
        (*env)->CallStaticVoidMethod(env, activityClass, run);
    if ((*env)->ExceptionCheck(env))
    {
        (*env)->ExceptionDescribe(env);
        (*env)->ExceptionClear(env);
    }
    (*env)->DeleteLocalRef(env, activityClass);
    (*env)->DeleteLocalRef(env, activity);
    return 0;
}
